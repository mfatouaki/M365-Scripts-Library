<#
.SYNOPSIS
Journaux de connexion entre deux dates UTC ; retention et licences du tenant s'appliquent.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId,
      [datetimeoffset]$FromUtc=([datetimeoffset]::UtcNow.AddDays(-7)),
      [datetimeoffset]$ToUtc=([datetimeoffset]::UtcNow), [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
if ($FromUtc -ge $ToUtc -or ($ToUtc-$FromUtc).TotalDays -gt 30) { throw 'Intervalle croissant de 30 jours maximum requis.' }
$filter = [uri]::EscapeDataString(("createdDateTime ge {0} and createdDateTime le {1}" -f $FromUtc.UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ssZ"),$ToUtc.UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ssZ")))
$folder = New-M365ReportFolder -Name 'signins' -OutputRoot $OutputRoot
$rows = @(Get-M365GraphCollection -Uri ('/v1.0/auditLogs/signIns?$filter='+$filter+'&$top=1000'))
Export-M365Report -Folder $folder -Name 'signins' -Data $rows
