<#
.SYNOPSIS
Membres directs de groupes Entra specifies par CSV, sans expansion transitive.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$groups = @(Import-M365Csv -Path $CsvPath -RequiredColumns GroupId -UniqueColumn GroupId)
$folder = New-M365ReportFolder -Name 'group-members' -OutputRoot $OutputRoot
$rows = @(foreach ($group in $groups) {
    $id = ConvertTo-M365Segment $group.GroupId
    foreach ($member in @(Get-M365GraphCollection -Uri "/v1.0/groups/$id/members")) {
        [pscustomobject]@{GroupId=$group.GroupId;MemberId=$member.id;Type=$member.'@odata.type';Details=(ConvertTo-Json -InputObject $member -Depth 10 -Compress)}
    }
})
Export-M365Report -Folder $folder -Name 'members' -Data $rows
