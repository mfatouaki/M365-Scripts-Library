<#
.SYNOPSIS
Politiques de reunion, messagerie et federation ; definitions seulement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Teams -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-TeamsPolicies' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'meeting-policies' -Data @(Get-CsTeamsMeetingPolicy -ErrorAction Stop | Select-Object Identity,AllowAnonymousUsersToJoinMeeting,AllowCloudRecording,AllowTranscription,AllowExternalParticipantGiveRequestControl)
Export-M365Report -Folder $folder -Name 'messaging-policies' -Data @(Get-CsTeamsMessagingPolicy -ErrorAction Stop | Select-Object Identity,AllowUserEditMessage,AllowUserDeleteMessage,AllowGiphy,AllowUrlPreviews,AllowUserChat)
Export-M365Report -Folder $folder -Name 'federation' -Data @(Get-CsTenantFederationConfiguration -ErrorAction Stop | Select-Object AllowFederatedUsers,AllowPublicUsers,AllowedDomains,BlockedDomains)
