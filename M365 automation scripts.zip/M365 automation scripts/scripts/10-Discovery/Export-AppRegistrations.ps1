<#
.SYNOPSIS
Applications et metadonnees de certificats/secrets ; pas leurs valeurs.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-AppRegistrations' -OutputRoot $OutputRoot

$rows = @(Get-M365GraphCollection -Uri '/v1.0/applications?$select=id,appId,displayName,signInAudience,passwordCredentials,keyCredentials,requiredResourceAccess')
Export-M365Report -Folder $folder -Name 'inventory' -Data $rows
