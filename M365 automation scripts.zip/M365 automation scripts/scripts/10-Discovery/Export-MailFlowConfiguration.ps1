<#
.SYNOPSIS
Domaines acceptes, connecteurs et regles de transport ; export documentaire.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-MailFlowConfiguration' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'accepted-domains' -Data @(Get-AcceptedDomain -ErrorAction Stop | Select-Object Name,DomainName,DomainType,Default)
Export-M365Report -Folder $folder -Name 'inbound-connectors' -Data @(Get-InboundConnector -ErrorAction Stop | Select-Object Identity,Enabled,ConnectorType,SenderDomains,SenderIPAddresses,RequireTls,RestrictDomainsToCertificate,TlsSenderCertificateName)
Export-M365Report -Folder $folder -Name 'outbound-connectors' -Data @(Get-OutboundConnector -ErrorAction Stop | Select-Object Identity,Enabled,ConnectorType,RecipientDomains,SmartHosts,UseMXRecord,TlsSettings,TlsDomain)
Export-M365Report -Folder $folder -Name 'transport-rules' -Data @(Get-TransportRule -ErrorAction Stop | Select-Object Name,Priority,State,Mode,Description)
