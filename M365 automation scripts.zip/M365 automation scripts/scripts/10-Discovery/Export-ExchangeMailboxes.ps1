<#
.SYNOPSIS
Boites aux lettres, tailles, archivage, retention et limites.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-ExchangeMailboxes' -OutputRoot $OutputRoot
$mailboxes = @(Get-EXOMailbox -ResultSize Unlimited -Properties ArchiveStatus,RetentionPolicy,LitigationHoldEnabled,ProhibitSendReceiveQuota,ForwardingSmtpAddress,DeliverToMailboxAndForward -ErrorAction Stop)
Export-M365Report -Folder $folder -Name 'mailboxes' -Data @($mailboxes | Select-Object ExternalDirectoryObjectId,DisplayName,UserPrincipalName,PrimarySmtpAddress,RecipientTypeDetails,ArchiveStatus,RetentionPolicy,LitigationHoldEnabled,ProhibitSendReceiveQuota,ForwardingSmtpAddress,DeliverToMailboxAndForward)
$stats = @(foreach ($m in $mailboxes) {
    Get-EXOMailboxStatistics -Identity $m.UserPrincipalName -ErrorAction Stop | Select-Object @{n='UserPrincipalName';e={$m.UserPrincipalName}},DisplayName,ItemCount,TotalItemSize,TotalDeletedItemSize,LastLogonTime
})
Export-M365Report -Folder $folder -Name 'statistics' -Data $stats
