<#
.SYNOPSIS
Groupes, types, regles dynamiques et proprietes de synchronisation.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-EntraGroups' -OutputRoot $OutputRoot

$rows = @(Get-M365GraphCollection -Uri '/v1.0/groups?$select=id,displayName,mail,mailEnabled,securityEnabled,groupTypes,onPremisesSyncEnabled,membershipRule,membershipRuleProcessingState&$top=999')
Export-M365Report -Folder $folder -Name 'inventory' -Data $rows
