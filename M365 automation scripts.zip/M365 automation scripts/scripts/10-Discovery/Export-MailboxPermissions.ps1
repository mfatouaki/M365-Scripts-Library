<#
.SYNOPSIS
FullAccess, SendAs et SendOnBehalf sur les boites selectionnees.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-MailboxPermissions' -OutputRoot $OutputRoot
$inputRows = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName -UniqueColumn UserPrincipalName)
$rows = @(foreach ($r in $inputRows) {
    $m = Get-Mailbox -Identity $r.UserPrincipalName -ErrorAction Stop
    foreach ($p in @(Get-MailboxPermission -Identity $m.Identity -ErrorAction Stop)) {
        [pscustomobject]@{Mailbox=$r.UserPrincipalName;Type='FullAccessOrOther';Trustee=[string]$p.User;Rights=($p.AccessRights -join ';');Inherited=$p.IsInherited;Deny=$p.Deny}
    }
    foreach ($p in @(Get-RecipientPermission -Identity $m.Identity -ErrorAction Stop)) {
        [pscustomobject]@{Mailbox=$r.UserPrincipalName;Type='SendAs';Trustee=[string]$p.Trustee;Rights=($p.AccessRights -join ';');Inherited=$p.IsInherited;Deny=$null}
    }
    foreach ($p in @($m.GrantSendOnBehalfTo)) {
        [pscustomobject]@{Mailbox=$r.UserPrincipalName;Type='SendOnBehalf';Trustee=[string]$p;Rights='SendOnBehalf';Inherited=$false;Deny=$false}
    }
})
Export-M365Report -Folder $folder -Name 'permissions' -Data $rows
