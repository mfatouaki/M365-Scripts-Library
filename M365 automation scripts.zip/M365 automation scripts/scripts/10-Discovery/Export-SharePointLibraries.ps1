<#
.SYNOPSIS
Bibliotheques et configurations d'un site. N'exporte pas le contenu des fichiers.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][uri]$SiteUrl, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-PnPUrl -Url $SiteUrl
$folder = New-M365ReportFolder -Name 'sharepoint-libraries' -OutputRoot $OutputRoot
$rows = @(Get-PnPList -Includes RootFolder,EnableVersioning,MajorVersionLimit,EnableMinorVersions,EnableModeration -ErrorAction Stop |
    Where-Object { $_.BaseType -eq 'DocumentLibrary' -and -not $_.Hidden } |
    Select-Object Id,Title,ItemCount,EnableVersioning,MajorVersionLimit,EnableMinorVersions,EnableModeration,@{n='RootFolder';e={$_.RootFolder.ServerRelativeUrl}})
Export-M365Report -Folder $folder -Name 'libraries' -Data $rows
