<#
.SYNOPSIS
Etat des batches et utilisateurs de migration Exchange, sans contenu des messages.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-MigrationStatus' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'batches' -Data @(Get-MigrationBatch -ErrorAction Stop | Select-Object Identity,Status,TotalCount,SyncedCount,FailedCount,StoppedCount,MigrationType)
Export-M365Report -Folder $folder -Name 'users' -Data @(Get-MigrationUser -ResultSize Unlimited -ErrorAction Stop | Select-Object Identity,BatchId,Status,RecipientType)
$statistics = @(Get-MigrationUser -ResultSize Unlimited -ErrorAction Stop | ForEach-Object {
    Get-MigrationUserStatistics -Identity $_.Identity -ErrorAction Stop | Select-Object Identity,Status,StatusDetail,SyncedItemCount,SkippedItemCount,BytesTransferred,LastSuccessfulSyncTime,DataConsistencyScore,Error
})
Export-M365Report -Folder $folder -Name 'statistics' -Data $statistics
