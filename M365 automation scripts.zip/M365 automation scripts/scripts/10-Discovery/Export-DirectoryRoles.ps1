<#
.SYNOPSIS
Affectations de roles actives (hors eligibilites PIM).
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-DirectoryRoles' -OutputRoot $OutputRoot

$rows = @(Get-M365GraphCollection -Uri '/v1.0/roleManagement/directory/roleAssignments')
Export-M365Report -Folder $folder -Name 'inventory' -Data $rows
