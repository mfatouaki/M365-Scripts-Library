<#
.SYNOPSIS
Objets appareils Entra ; ce n'est pas un inventaire Intune.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-EntraDevices' -OutputRoot $OutputRoot

$rows = @(Get-M365GraphCollection -Uri '/v1.0/devices?$select=id,deviceId,displayName,operatingSystem,operatingSystemVersion,trustType,accountEnabled,isManaged,isCompliant,approximateLastSignInDateTime')
Export-M365Report -Folder $folder -Name 'inventory' -Data $rows
