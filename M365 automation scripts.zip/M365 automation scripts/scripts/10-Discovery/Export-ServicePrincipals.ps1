<#
.SYNOPSIS
Applications d'entreprise et statut, sans extraire de tokens.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-ServicePrincipals' -OutputRoot $OutputRoot

$rows = @(Get-M365GraphCollection -Uri '/v1.0/servicePrincipals?$select=id,appId,displayName,accountEnabled,servicePrincipalType,appOwnerOrganizationId')
Export-M365Report -Folder $folder -Name 'inventory' -Data $rows
