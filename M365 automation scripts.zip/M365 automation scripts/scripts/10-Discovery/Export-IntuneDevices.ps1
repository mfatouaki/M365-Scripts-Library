<#
.SYNOPSIS
Inventaire des appareils geres Intune ; ne declenche pas de sync ni de wipe.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'intune-devices' -OutputRoot $OutputRoot
$rows = @(Get-M365GraphCollection -Uri '/v1.0/deviceManagement/managedDevices?$select=id,deviceName,userPrincipalName,operatingSystem,osVersion,complianceState,managementAgent,lastSyncDateTime,enrolledDateTime,azureADDeviceId')
Export-M365Report -Folder $folder -Name 'devices' -Data $rows
