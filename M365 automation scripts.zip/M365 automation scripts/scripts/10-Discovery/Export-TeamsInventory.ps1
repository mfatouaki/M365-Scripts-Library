<#
.SYNOPSIS
Equipes visibles par le compte et canaux ; ne recense pas les chats.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Teams -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-TeamsInventory' -OutputRoot $OutputRoot
$teams = @(Get-Team -ErrorAction Stop)
Export-M365Report -Folder $folder -Name 'teams' -Data @($teams | Select-Object GroupId,DisplayName,Description,Visibility,Archived)
$channels = @(foreach ($team in $teams) {
    Get-TeamChannel -GroupId $team.GroupId -ErrorAction Stop | Select-Object @{n='GroupId';e={$team.GroupId}},Id,DisplayName,MembershipType
})
Export-M365Report -Folder $folder -Name 'channels' -Data $channels
