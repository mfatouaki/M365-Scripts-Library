<#
.SYNOPSIS
Inventaire utilisateurs, synchronisation, licences et plans de service.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'Export-EntraUsers' -OutputRoot $OutputRoot

$rows = @(Get-M365GraphCollection -Uri '/v1.0/users?$select=id,displayName,userPrincipalName,mail,userType,accountEnabled,usageLocation,onPremisesSyncEnabled,onPremisesImmutableId,assignedLicenses,assignedPlans,createdDateTime&$top=999')
Export-M365Report -Folder $folder -Name 'inventory' -Data $rows
