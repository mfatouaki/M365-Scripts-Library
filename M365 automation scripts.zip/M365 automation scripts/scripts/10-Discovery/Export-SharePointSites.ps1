<#
.SYNOPSIS
Sites SharePoint et OneDrive, quotas, partage et verrouillage. Connexion PnP a l'admin URL requise.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][uri]$AdminUrl, [switch]$IncludeOneDrive, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-PnPUrl -Url $AdminUrl
if ($AdminUrl.Host -notmatch '-admin\.sharepoint\.com$') { throw 'URL admin SharePoint public attendue.' }
$folder = New-M365ReportFolder -Name 'sharepoint-sites' -OutputRoot $OutputRoot
$sites = @(Get-PnPTenantSite -Detailed -IncludeOneDriveSites:$IncludeOneDrive -ErrorAction Stop)
Export-M365Report -Folder $folder -Name 'sites' -Data @($sites | Select-Object Url,Title,Owner,Template,StorageQuota,StorageUsageCurrent,SharingCapability,LockState,LastContentModifiedDate)
