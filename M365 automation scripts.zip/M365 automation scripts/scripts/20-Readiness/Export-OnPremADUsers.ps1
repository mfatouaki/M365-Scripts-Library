<#
.SYNOPSIS
Inventaire AD source (RSAT requis), sans mots de passe et sans changer AD.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$Server, [Parameter(Mandatory)][string]$SearchBase, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime

Import-Module ActiveDirectory -ErrorAction Stop
$folder = New-M365ReportFolder -Name 'ad-users' -OutputRoot $OutputRoot
$rows = @(Get-ADUser -Server $Server -SearchBase $SearchBase -Filter * -Properties mail,proxyAddresses,msDS-ConsistencyGuid,Enabled,UserPrincipalName -ErrorAction Stop | ForEach-Object {
    $anchor = $_.'msDS-ConsistencyGuid'
    [pscustomobject]@{SamAccountName=$_.SamAccountName;UserPrincipalName=$_.UserPrincipalName;Mail=$_.mail;Enabled=$_.Enabled;ObjectGuid=[string]$_.ObjectGuid;ConsistencyGuidBase64=$(if($anchor){[Convert]::ToBase64String([byte[]]$anchor)}else{''});ProxyAddresses=($_.proxyAddresses -join ';');DistinguishedName=$_.DistinguishedName}
})
Export-M365Report -Folder $folder -Name 'users' -Data $rows
