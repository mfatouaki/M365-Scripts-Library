<#
.SYNOPSIS
Controle local du mapping source/cible ; n'interroge pas les annuaires.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$CsvPath, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns SourceUPN,TargetUPN -UniqueColumn SourceUPN)
$targets = @($rows | Group-Object TargetUPN | Where-Object Count -gt 1 | ForEach-Object Name)
$checks = @(foreach ($r in $rows) {
    $issues = [Collections.Generic.List[string]]::new()
    foreach ($column in @('SourceUPN','TargetUPN')) {
        if ($r.$column -notmatch '^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$') { $issues.Add("Format UPN suspect : $column") }
        if ($r.$column -ne $r.$column.Trim()) { $issues.Add("Espaces dans $column") }
    }
    if ($r.TargetUPN -in $targets) { $issues.Add('Cible dupliquee') }
    [pscustomobject]@{SourceUPN=$r.SourceUPN;TargetUPN=$r.TargetUPN;Valid=($issues.Count -eq 0);Issues=($issues -join ';')}
})
$folder = New-M365ReportFolder -Name 'identity-mapping' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'checks' -Data $checks
if (@($checks | Where-Object { -not $_.Valid }).Count -gt 0) { throw 'Mapping invalide. Corriger avant migration.' }
