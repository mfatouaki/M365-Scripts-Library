<#
.SYNOPSIS
Analyse un partage sans copier les fichiers. Controle indicatif, pas substitut a SPMT.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SourcePath, [ValidateRange(0,399)][int]$TargetPrefixLength=100, [ValidateRange(1,10000000)][int]$MaxFiles=100000, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime

$root = (Resolve-Path -LiteralPath $SourcePath -ErrorAction Stop).ProviderPath.TrimEnd('\','/')
if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw 'Dossier source requis.' }
$folder = New-M365ReportFolder -Name 'file-readiness' -OutputRoot $OutputRoot
$rows = [Collections.Generic.List[object]]::new()
$scanErrors = @()
$count = 0
$truncated = $false
Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue -ErrorVariable +scanErrors | ForEach-Object {
    $count++
    if ($count -le $MaxFiles) {
        $rel = $_.FullName.Substring($root.Length).TrimStart('\','/')
        $issues = [Collections.Generic.List[string]]::new()
        if (($TargetPrefixLength+$rel.Length) -gt 400) { $issues.Add('Chemin cible estime > 400 caracteres decodes') }
        if ($_.Length -gt 250GB) { $issues.Add('Fichier > 250 Go') }
        foreach ($segment in ($rel -split '[\\/]')) {
            if ($segment -match '["*:<>?\|]' -or $segment -match '(^ | $|\.$)' -or $segment -match '^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\.|$)' -or $segment -ieq '.lock' -or $segment -ieq 'desktop.ini' -or $segment -match '^~\$' -or $segment -match '_vti_') { $issues.Add("Nom a verifier : $segment") }
        }
        $rows.Add([pscustomobject]@{RelativePath=$rel;Bytes=$_.Length;LastWriteUtc=$_.LastWriteTimeUtc.ToString('o');ReviewRequired=($issues.Count -gt 0);Issues=($issues -join ';')})
    } else { $truncated=$true }
}
Export-M365Report -Folder $folder -Name 'files' -Data $rows.ToArray()
Export-M365Report -Folder $folder -Name 'scan-errors' -Data @($scanErrors | ForEach-Object { [pscustomobject]@{Target=[string]$_.TargetObject;Error=$_.Exception.Message} })
Export-M365Report -Folder $folder -Name 'summary' -Data @([pscustomobject]@{Source=$root;FilesSeen=$count;FilesReported=$rows.Count;Truncated=$truncated;AccessErrors=$scanErrors.Count;TotalBytesReported=($rows | Measure-Object Bytes -Sum).Sum})
if ($truncated -or $scanErrors.Count -gt 0) { throw 'Inventaire incomplet (limite ou acces). Lire les rapports et ajuster avant toute conclusion.' }
