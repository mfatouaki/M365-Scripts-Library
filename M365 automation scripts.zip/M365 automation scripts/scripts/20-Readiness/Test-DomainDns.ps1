<#
.SYNOPSIS
Observe MX, SPF et DMARC via le DNS configure ; ne change aucun enregistrement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$Domain, [string]$DnsServer, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime

if ($Domain -notmatch '^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') { throw 'Nom de domaine invalide.' }
$folder = New-M365ReportFolder -Name 'dns' -OutputRoot $OutputRoot
$rows = @(foreach ($query in @(@{Name=$Domain;Type='MX'},@{Name=$Domain;Type='TXT'},@{Name="_dmarc.$Domain";Type='TXT'},@{Name="autodiscover.$Domain";Type='CNAME'},@{Name="selector1._domainkey.$Domain";Type='CNAME'},@{Name="selector2._domainkey.$Domain";Type='CNAME'})) {
    $args = @{Name=$query.Name;Type=$query.Type;DnsOnly=$true;ErrorAction='Stop'}
    if ($DnsServer) { $args.Server=$DnsServer }
    try {
        $records = @(Resolve-DnsName @args)
        [pscustomobject]@{Name=$query.Name;Type=$query.Type;Status='Resolved';Records=(ConvertTo-Json -InputObject $records -Depth 10 -Compress);Error=''}
    } catch { [pscustomobject]@{Name=$query.Name;Type=$query.Type;Status='Unresolved';Records='';Error=$_.Exception.Message} }
})
Export-M365Report -Folder $folder -Name 'dns' -Data $rows
Write-Warning 'Selectors DKIM 1/2 conventionnels seulement. Comparer les valeurs exactes au tenant ; DNS resolu ne prouve pas un flux mail correct.'
