<#
.SYNOPSIS
Decoupe un CSV EmailAddress en vagues deterministes ; aucune planification cloud.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$CsvPath, [ValidateRange(1,5000)][int]$WaveSize=50, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns EmailAddress -UniqueColumn EmailAddress)
foreach ($r in $rows) { if ($r.EmailAddress -notmatch '^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$') { throw "Adresse invalide : $($r.EmailAddress)" } }
$rows = @($rows | Sort-Object EmailAddress)
$folder = New-M365ReportFolder -Name 'migration-waves' -OutputRoot $OutputRoot
$manifest = @(for ($start=0; $start -lt $rows.Count; $start+=$WaveSize) {
    $end = [Math]::Min($start+$WaveSize-1,$rows.Count-1)
    $name = 'wave-{0:d3}.csv' -f ([int][Math]::Floor($start/$WaveSize)+1)
    $rows[$start..$end] | Select-Object EmailAddress | Export-Csv -LiteralPath (Join-Path $folder $name) -NoTypeInformation -Encoding utf8
    [pscustomobject]@{File=$name;Users=($end-$start+1)}
})
Export-M365Report -Folder $folder -Name 'waves' -Data $manifest
Write-Warning 'Decoupage alphabetique uniquement : ajuster pour dependances, VIP, delegates, taille et fenetres metier.'
