<#
.SYNOPSIS
Verifie existence, compte actif, synchronisation et licences des utilisateurs cibles.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime
Assert-M365Context -Service Graph -TenantId $TenantId
$inputRows = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName -UniqueColumn UserPrincipalName)
$folder = New-M365ReportFolder -Name 'target-users' -OutputRoot $OutputRoot
$rows = @(foreach ($r in $inputRows) {
    try {
        $id = ConvertTo-M365Segment $r.UserPrincipalName
        $u = Invoke-M365Graph -Uri ("/v1.0/users/$id"+'?$select=id,userPrincipalName,accountEnabled,usageLocation,onPremisesSyncEnabled,assignedLicenses')
        [pscustomobject]@{UserPrincipalName=$r.UserPrincipalName;Found=$true;AccountEnabled=$u.accountEnabled;UsageLocation=$u.usageLocation;Synced=$u.onPremisesSyncEnabled;LicenseCount=@($u.assignedLicenses).Count;Error=''}
    } catch { [pscustomobject]@{UserPrincipalName=$r.UserPrincipalName;Found=$false;AccountEnabled=$null;UsageLocation='';Synced=$null;LicenseCount=$null;Error=$_.Exception.Message} }
})
Export-M365Report -Folder $folder -Name 'checks' -Data $rows
if (@($rows | Where-Object { -not $_.Found -or -not $_.AccountEnabled }).Count -gt 0) { throw 'Cibles introuvables/inactives ou erreur API. Lire les checks.' }
