<#
.SYNOPSIS
Valide un CSV Exchange EmailAddress, sans lancer de migration.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$CsvPath, [ValidateRange(1,100000)][int]$MaxUsers=100, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns EmailAddress -UniqueColumn EmailAddress)
if ($rows.Count -gt $MaxUsers) { throw "Vague de $($rows.Count) utilisateurs > MaxUsers=$MaxUsers." }
if (@($rows[0].PSObject.Properties.Name).Count -ne 1) { throw 'Modele RemoteMove : seule la colonne EmailAddress est acceptee.' }
foreach ($r in $rows) { if ($r.EmailAddress -notmatch '^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$') { throw "Adresse invalide : $($r.EmailAddress)" } }
$folder = New-M365ReportFolder -Name 'migration-wave' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'validated-wave' -Data $rows
