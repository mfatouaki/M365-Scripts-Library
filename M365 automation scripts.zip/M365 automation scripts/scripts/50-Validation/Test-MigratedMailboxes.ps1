<#
.SYNOPSIS
Controle presence, type, statistiques et archivage apres migration.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId
$inputs = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName -UniqueColumn UserPrincipalName)
$folder = New-M365ReportFolder -Name 'post-migration-mailboxes' -OutputRoot $OutputRoot
$rows = @(foreach ($r in $inputs) {
    try {
        $m = Get-EXOMailbox -Identity $r.UserPrincipalName -Properties ArchiveStatus -ErrorAction Stop
        $s = Get-EXOMailboxStatistics -Identity $r.UserPrincipalName -ErrorAction Stop
        [pscustomobject]@{UserPrincipalName=$r.UserPrincipalName;Found=$true;Type=[string]$m.RecipientTypeDetails;ArchiveStatus=$m.ArchiveStatus;ItemCount=$s.ItemCount;TotalItemSize=[string]$s.TotalItemSize;Error=''}
    } catch { [pscustomobject]@{UserPrincipalName=$r.UserPrincipalName;Found=$false;Type='';ArchiveStatus='';ItemCount=$null;TotalItemSize='';Error=$_.Exception.Message} }
})
Export-M365Report -Folder $folder -Name 'checks' -Data $rows
if (@($rows | Where-Object { -not $_.Found }).Count -gt 0) { throw 'Au moins une boite manquante ou un controle a echoue.' }
Write-Warning 'Presence/statistiques ne prouvent pas integralite. Tester mail interne/externe, Outlook, mobile, calendrier, delegations, archives et echantillons de donnees.'
