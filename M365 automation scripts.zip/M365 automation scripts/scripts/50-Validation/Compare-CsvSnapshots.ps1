<#
.SYNOPSIS
Compare deux exports CSV par cle et colonnes explicites ; aucune restauration automatique.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][string]$BeforePath, [Parameter(Mandatory)][string]$AfterPath, [Parameter(Mandatory)][string]$KeyColumn, [Parameter(Mandatory)][string[]]$Columns, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime

$required = @($KeyColumn)+$Columns
$before = @(Import-M365Csv -Path $BeforePath -RequiredColumns @($KeyColumn) -UniqueColumn $KeyColumn)
$after = @(Import-M365Csv -Path $AfterPath -RequiredColumns @($KeyColumn) -UniqueColumn $KeyColumn)
foreach ($dataset in @($before[0],$after[0])) {
    foreach ($c in $required) { if ($c -notin @($dataset.PSObject.Properties.Name)) { throw "Colonne absente : $c" } }
}
$b = @{}; $a = @{}
foreach ($r in $before) { $b[[string]$r.$KeyColumn]=$r }
foreach ($r in $after) { $a[[string]$r.$KeyColumn]=$r }
$keys = @(@($b.Keys)+@($a.Keys) | Sort-Object -Unique)
$diffs = @(foreach ($key in $keys) {
    if (-not $b.ContainsKey($key)) { [pscustomobject]@{Key=$key;Change='Added';Column='';Before='';After=''}; continue }
    if (-not $a.ContainsKey($key)) { [pscustomobject]@{Key=$key;Change='Removed';Column='';Before='';After=''}; continue }
    foreach ($c in $Columns) {
        if ([string]$b[$key].$c -cne [string]$a[$key].$c) { [pscustomobject]@{Key=$key;Change='Changed';Column=$c;Before=$b[$key].$c;After=$a[$key].$c} }
    }
})
$folder = New-M365ReportFolder -Name 'snapshot-diff' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'differences' -Data $diffs
