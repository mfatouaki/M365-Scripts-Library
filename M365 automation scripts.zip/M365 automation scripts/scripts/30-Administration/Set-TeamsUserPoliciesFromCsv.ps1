<#
.SYNOPSIS
Assigne des politiques directes de reunion et messagerie existantes. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Teams -TenantId $TenantId

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName,MeetingPolicy,MessagingPolicy -UniqueColumn UserPrincipalName)
$folder = New-M365ReportFolder -Name 'teams-user-policies' -OutputRoot $OutputRoot
Invoke-M365CsvChange -Caller $PSCmdlet -Rows $rows -Folder $folder -Apply:$Apply -Action 'Assigner deux politiques Teams directes' -Validate {
    param($r)
    $u = Get-CsOnlineUser -Identity $r.UserPrincipalName -ErrorAction Stop
    $null = Get-CsTeamsMeetingPolicy -Identity $r.MeetingPolicy -ErrorAction Stop
    $null = Get-CsTeamsMessagingPolicy -Identity $r.MessagingPolicy -ErrorAction Stop
    [pscustomobject]@{Target=$r.UserPrincipalName;MeetingPolicy=$r.MeetingPolicy;MessagingPolicy=$r.MessagingPolicy;BeforeMeeting=$u.TeamsMeetingPolicy;BeforeMessaging=$u.TeamsMessagingPolicy}
} -Execute {
    param($p)
    Grant-CsTeamsMeetingPolicy -Identity $p.Target -PolicyName $p.MeetingPolicy -ErrorAction Stop
    Grant-CsTeamsMessagingPolicy -Identity $p.Target -PolicyName $p.MessagingPolicy -ErrorAction Stop
}
Write-Warning 'Les deux affectations ne sont pas transactionnelles. Une ligne Failed peut avoir applique la premiere politique. Verifier chaque politique effective apres propagation.'
