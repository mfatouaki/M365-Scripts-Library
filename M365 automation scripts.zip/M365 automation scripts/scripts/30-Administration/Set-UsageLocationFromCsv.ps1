<#
.SYNOPSIS
Definit UsageLocation avant attribution de licences. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName,UsageLocation -UniqueColumn UserPrincipalName)
$folder = New-M365ReportFolder -Name 'usage-location' -OutputRoot $OutputRoot
Invoke-M365CsvChange -Caller $PSCmdlet -Rows $rows -Folder $folder -Apply:$Apply -Action 'Definir UsageLocation' -Validate {
    param($r)
    $country = $r.UsageLocation.ToUpperInvariant()
    if ($country -notmatch '^[A-Z]{2}$') { throw "Code ISO pays invalide : $country" }
    try { $region = [Globalization.RegionInfo]::new($country) } catch { throw "Pays non reconnu : $country" }
    if ($region.TwoLetterISORegionName -ne $country) { throw "Code pays incorrect : $country" }
    $id = ConvertTo-M365Segment $r.UserPrincipalName
    $u = Invoke-M365Graph -Uri ("/v1.0/users/$id"+'?$select=id,userPrincipalName,usageLocation')
    [pscustomobject]@{Target=$u.userPrincipalName;Id=$u.id;Before=$u.usageLocation;After=$country;Changed=($u.usageLocation -ne $country)}
} -Execute {
    param($p)
    if ($p.Changed) { Invoke-M365Graph -Uri "/v1.0/users/$($p.Id)" -Method PATCH -Body @{usageLocation=$p.After} }
}
