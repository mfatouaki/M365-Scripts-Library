<#
.SYNOPSIS
Accorde FullAccess ou SendAs ; pas de retrait de droits. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns Mailbox,Trustee,Permission,AutoMapping)
$folder = New-M365ReportFolder -Name 'mailbox-delegation' -OutputRoot $OutputRoot
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
Invoke-M365CsvChange -Caller $PSCmdlet -Rows $rows -Folder $folder -Apply:$Apply -Action 'Accorder une delegation de boite' -Validate {
    param($r)
    if ($r.Permission -notin @('FullAccess','SendAs')) { throw 'Permission : FullAccess ou SendAs seulement.' }
    if ($r.AutoMapping -notin @('true','false')) { throw 'AutoMapping : true ou false.' }
    $m = Get-Mailbox -Identity $r.Mailbox -ErrorAction Stop
    $t = Get-Recipient -Identity $r.Trustee -ErrorAction Stop
    if (-not $seen.Add("$($m.Guid)/$($t.Guid)/$($r.Permission)")) { throw 'Delegation dupliquee.' }
    if ($r.Permission -eq 'FullAccess') {
        $existing = @(Get-MailboxPermission -Identity $m.Identity -User $t.Identity -ErrorAction Stop | Where-Object { -not $_.Deny -and 'FullAccess' -in $_.AccessRights })
    } else {
        $existing = @(Get-RecipientPermission -Identity $m.Identity -Trustee $t.Identity -ErrorAction Stop | Where-Object { 'SendAs' -in $_.AccessRights })
    }
    [pscustomobject]@{Target="$($m.PrimarySmtpAddress)/$($t.PrimarySmtpAddress)/$($r.Permission)";Mailbox=[string]$m.PrimarySmtpAddress;Trustee=[string]$t.PrimarySmtpAddress;Permission=$r.Permission;AutoMapping=($r.AutoMapping -eq 'true');AlreadyGranted=($existing.Count -gt 0);Before=$existing}
} -Execute {
    param($p)
    if (-not $p.AlreadyGranted) {
        if ($p.Permission -eq 'FullAccess') { Add-MailboxPermission -Identity $p.Mailbox -User $p.Trustee -AccessRights FullAccess -InheritanceType All -AutoMapping:$p.AutoMapping -Confirm:$false -ErrorAction Stop }
        else { Add-RecipientPermission -Identity $p.Mailbox -Trustee $p.Trustee -AccessRights SendAs -Confirm:$false -ErrorAction Stop }
    }
}
Write-Warning 'AutoMapping non reconfigure si FullAccess existe deja. La propagation et Outlook demandent une validation utilisateur.'
