<#
.SYNOPSIS
Configure langue et fuseau des boites ; ne renomme pas les dossiers. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName,Language,TimeZone -UniqueColumn UserPrincipalName)
$folder = New-M365ReportFolder -Name 'mailbox-regional-settings' -OutputRoot $OutputRoot
Invoke-M365CsvChange -Caller $PSCmdlet -Rows $rows -Folder $folder -Apply:$Apply -Action 'Configurer langue et fuseau horaire' -Validate {
    param($r)
    $null = [Globalization.CultureInfo]::GetCultureInfo($r.Language)
    $null = [TimeZoneInfo]::FindSystemTimeZoneById($r.TimeZone)
    $m = Get-Mailbox -Identity $r.UserPrincipalName -ErrorAction Stop
    $before = Get-MailboxRegionalConfiguration -Identity $m.Identity -ErrorAction Stop | Select-Object Language,TimeZone,DateFormat,TimeFormat
    [pscustomobject]@{Target=[string]$m.PrimarySmtpAddress;Language=$r.Language;TimeZone=$r.TimeZone;Before=$before}
} -Execute {
    param($p)
    Set-MailboxRegionalConfiguration -Identity $p.Target -Language $p.Language -TimeZone $p.TimeZone -ErrorAction Stop
}
