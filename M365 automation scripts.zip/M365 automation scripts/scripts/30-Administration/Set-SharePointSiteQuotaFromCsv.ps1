<#
.SYNOPSIS
Change les quotas sites en mode manuel du tenant. Ne change pas le mode de stockage global.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][uri]$AdminUrl, [Parameter(Mandatory)][string]$CsvPath, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-PnPUrl -Url $AdminUrl
if ($AdminUrl.Host -notmatch '-admin\.sharepoint\.com$') { throw 'URL admin SharePoint requise.' }
$tenant = Get-PnPTenant -ErrorAction Stop
if ([string]$tenant.StorageQuotaType -ne 'Manual') { throw 'Quotas individuels : tenant en mode Manual requis. Pas de bascule globale automatique.' }
$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns SiteUrl,StorageQuotaMB,WarningQuotaMB -UniqueColumn SiteUrl)
$folder = New-M365ReportFolder -Name 'sharepoint-quota' -OutputRoot $OutputRoot
Invoke-M365CsvChange -Caller $PSCmdlet -Rows $rows -Folder $folder -Apply:$Apply -Action 'Definir quota et seuil du site' -Validate {
    param($r)
    $url = [uri]$r.SiteUrl
    $expectedHost = $AdminUrl.Host -replace '-admin\.sharepoint','.sharepoint'
    if ($url.Scheme -ne 'https' -or $url.Host -ne $expectedHost -or $url.UserInfo) { throw 'Seuls les sites du tenant SharePoint connecte sont acceptes.' }
    $quota = [long]$r.StorageQuotaMB; $warning = [long]$r.WarningQuotaMB
    if ($quota -lt 1 -or $quota -gt 26214400 -or $warning -lt 1 -or $warning -ge $quota) { throw 'Quotas MB invalides (max site 25 To ; seuil < quota).' }
    $site = Get-PnPTenantSite -Identity $url.AbsoluteUri -Detailed -ErrorAction Stop
    if ($quota -lt $site.StorageUsageCurrent) { throw 'Quota inferieur au stockage utilise.' }
    [pscustomobject]@{Target=$url.AbsoluteUri;Quota=$quota;Warning=$warning;BeforeQuota=$site.StorageQuota;BeforeWarning=$site.StorageQuotaWarningLevel}
} -Execute {
    param($p)
    Set-PnPTenantSite -Identity $p.Target -StorageQuota $p.Quota -StorageQuotaWarningLevel $p.Warning -ErrorAction Stop
}
