<#
.SYNOPSIS
Ajoute des utilisateurs aux groupes cloud statiques Entra ou M365. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns GroupId,UserPrincipalName)
$folder = New-M365ReportFolder -Name 'add-group-members' -OutputRoot $OutputRoot
$groups = @{}; $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
Invoke-M365CsvChange -Caller $PSCmdlet -Rows $rows -Folder $folder -Apply:$Apply -Action 'Ajouter un membre direct' -Validate {
    param($r)
    $gid = [string][guid]$r.GroupId
    $uid = ConvertTo-M365Segment $r.UserPrincipalName
    $u = Invoke-M365Graph -Uri ("/v1.0/users/$uid"+'?$select=id,userPrincipalName')
    if (-not $seen.Add("$gid/$($u.id)")) { throw 'Couple groupe/utilisateur duplique.' }
    if (-not $groups.ContainsKey($gid)) {
        $g = Invoke-M365Graph -Uri ("/v1.0/groups/$gid"+'?$select=id,displayName,groupTypes,mailEnabled,onPremisesSyncEnabled,isAssignableToRole')
        if ($g.onPremisesSyncEnabled -eq $true -or 'DynamicMembership' -in $g.groupTypes -or $g.isAssignableToRole -eq $true) { throw 'Groupe synchronise, dynamique ou assignable a un role : non pris en charge.' }
        if ($g.mailEnabled -and 'Unified' -notin $g.groupTypes) { throw 'Groupe de distribution/securite mail : utiliser Exchange.' }
        $groups[$gid] = @{Group=$g;Members=@(Get-M365GraphCollection -Uri "/v1.0/groups/$gid/members" | ForEach-Object id)}
    }
    [pscustomobject]@{Target="$gid/$($u.userPrincipalName)";GroupId=$gid;UserId=$u.id;AlreadyMember=($u.id -in $groups[$gid].Members)}
} -Execute {
    param($p)
    if (-not $p.AlreadyMember) {
        Invoke-M365Graph -Uri ("/v1.0/groups/$($p.GroupId)/members/"+'$ref') -Method POST -Body @{'@odata.id'="https://graph.microsoft.com/v1.0/directoryObjects/$($p.UserId)"}
    }
}
