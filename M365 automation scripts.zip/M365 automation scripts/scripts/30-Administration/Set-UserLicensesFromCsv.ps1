<#
.SYNOPSIS
Ajoute un SKU par utilisateur ; ne retire ni ne remplace de licence existante. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName,SkuId -UniqueColumn UserPrincipalName)
$skus = @(Get-M365GraphCollection -Uri '/v1.0/subscribedSkus')
$folder = New-M365ReportFolder -Name 'user-licenses' -OutputRoot $OutputRoot
$counts = @{}
Invoke-M365CsvChange -Caller $PSCmdlet -Rows $rows -Folder $folder -Apply:$Apply -Action 'Ajouter un SKU sans retirer de licences' -Validate {
    param($r)
    $skuId = [guid]$r.SkuId
    $sku = @($skus | Where-Object { [string]$_.skuId -eq [string]$skuId })
    if ($sku.Count -ne 1 -or $sku[0].capabilityStatus -ne 'Enabled') { throw "SKU absent ou non actif : $skuId" }
    $id = ConvertTo-M365Segment $r.UserPrincipalName
    $u = Invoke-M365Graph -Uri ("/v1.0/users/$id"+'?$select=id,userPrincipalName,usageLocation,assignedLicenses')
    if (-not $u.usageLocation) { throw "UsageLocation absent pour $($r.UserPrincipalName)" }
    $assigned = @($u.assignedLicenses | ForEach-Object skuId)
    $already = [string]$skuId -in $assigned
    $key = [string]$skuId
    if (-not $counts.ContainsKey($key)) { $counts[$key]=0 }
    if (-not $already) { $counts[$key]++ }
    if ($counts[$key] -gt ([int]$sku[0].prepaidUnits.enabled-[int]$sku[0].consumedUnits)) { throw "Capacite insuffisante pour le lot : $skuId" }
    [pscustomobject]@{Target=$u.userPrincipalName;Id=$u.id;SkuId=$key;AlreadyAssigned=$already;Before=$u.assignedLicenses}
} -Execute {
    param($p)
    if (-not $p.AlreadyAssigned) {
        Invoke-M365Graph -Uri "/v1.0/users/$($p.Id)/assignLicense" -Method POST -Body @{addLicenses=@(@{skuId=$p.SkuId;disabledPlans=@()});removeLicenses=@()}
    }
}
Write-Warning 'Capacite ponctuelle uniquement : un autre administrateur peut consommer des licences entre validation et application. Licences par groupe/non modifiables a traiter dans leur groupe source.'
