<#
.SYNOPSIS
Completer et basculer un batch hybride Exchange. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$Name, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId

$batch = Get-MigrationBatch -Identity $Name -ErrorAction Stop
if ([string]$batch.MigrationType -ne 'ExchangeRemoteMove') { throw 'Ce script ne gere que ExchangeRemoteMove.' }
if ([string]$batch.Status -ne 'Synced' -or $null -eq $batch.FailedCount -or [int]$batch.FailedCount -ne 0) { throw 'Completion exige Synced et zero echec confirme.' }
$users = @(Get-MigrationUser -BatchId $Name -ResultSize Unlimited -ErrorAction Stop)
if ($users.Count -eq 0 -or $users.Count -ne [int]$batch.TotalCount) { throw 'Nombre utilisateurs incoherent : completion bloquee.' }
foreach ($u in $users) {
    $s = Get-MigrationUserStatistics -Identity $u.Identity -ErrorAction Stop
    if ($null -eq $s.SkippedItemCount) { throw "Compteur SkippedItemCount inconnu : $($u.Identity). Completion bloquee." }
    if ([string]$s.Status -ne 'Synced' -or [long]$s.SkippedItemCount -ne 0 -or $s.Error) { throw "Utilisateur non synchronise, elements ignores ou erreur : $($u.Identity). Traitement manuel requis." }
}
$folder = New-M365ReportFolder -Name 'complete-migration-batch' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'before' -Data @($batch | Select-Object Identity,Status,TotalCount,SyncedCount,FailedCount)
if ($Apply -and $PSCmdlet.ShouldProcess($Name,'Completer et basculer un batch hybride Exchange')) {
    Complete-MigrationBatch -Identity $Name -Confirm:$false -ErrorAction Stop
    $after = Get-MigrationBatch -Identity $Name -ErrorAction Stop
    Export-M365Report -Folder $folder -Name 'after' -Data @($after | Select-Object Identity,Status,TotalCount,SyncedCount,FailedCount)
}
Write-Warning 'Operation asynchrone : suivre Export-MigrationStatus. Pas de rollback automatique, ni d acceptation de pertes de donnees.'
