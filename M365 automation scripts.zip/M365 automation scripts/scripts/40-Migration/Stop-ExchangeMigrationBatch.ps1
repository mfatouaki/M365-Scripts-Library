<#
.SYNOPSIS
Arreter la synchronisation de un batch hybride Exchange. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$Name, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId

$batch = Get-MigrationBatch -Identity $Name -ErrorAction Stop
if ([string]$batch.MigrationType -ne 'ExchangeRemoteMove') { throw 'Ce script ne gere que ExchangeRemoteMove.' }
if ([string]$batch.Status -notin @('Starting','Syncing')) { throw 'Arret reserve a un batch Starting ou Syncing.' }
$folder = New-M365ReportFolder -Name 'stop-migration-batch' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'before' -Data @($batch | Select-Object Identity,Status,TotalCount,SyncedCount,FailedCount)
if ($Apply -and $PSCmdlet.ShouldProcess($Name,'Arreter la synchronisation de un batch hybride Exchange')) {
    Stop-MigrationBatch -Identity $Name -Confirm:$false -ErrorAction Stop
    $after = Get-MigrationBatch -Identity $Name -ErrorAction Stop
    Export-M365Report -Folder $folder -Name 'after' -Data @($after | Select-Object Identity,Status,TotalCount,SyncedCount,FailedCount)
}
Write-Warning 'Operation asynchrone : suivre Export-MigrationStatus. Pas de rollback automatique, ni d acceptation de pertes de donnees.'
