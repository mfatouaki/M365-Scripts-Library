<#
.SYNOPSIS
Cree un batch hybride RemoteMove sans le demarrer ni le completer. Sans Apply : plan uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][string]$EndpointName, [Parameter(Mandatory)][string]$TargetDeliveryDomain, [Parameter(Mandatory)][string]$CsvPath, [ValidateRange(1,10000)][int]$MaxUsers=100, [switch]$Apply, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId

$rows = @(Import-M365Csv -Path $CsvPath -RequiredColumns EmailAddress -UniqueColumn EmailAddress)
if ($rows.Count -gt $MaxUsers) { throw 'Vague trop grande.' }
if (@($rows[0].PSObject.Properties.Name).Count -ne 1) { throw 'Seule la colonne EmailAddress est autorisee pour ce script RemoteMove.' }
foreach ($r in $rows) { if ($r.EmailAddress -notmatch '^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$') { throw 'Adresse EmailAddress invalide.' } }
if ($TargetDeliveryDomain -notmatch '^[A-Za-z0-9.-]+\.mail\.onmicrosoft\.com$') { throw 'Domaine de routage hybride *.mail.onmicrosoft.com requis.' }
$endpoint = Get-MigrationEndpoint -Identity $EndpointName -ErrorAction Stop
if ([string]$endpoint.EndpointType -ne 'ExchangeRemoteMove') { throw 'Endpoint ExchangeRemoteMove existant requis.' }
$existing = @(Get-MigrationBatch -ErrorAction Stop | Where-Object { [string]$_.Identity -eq $Name })
if ($existing.Count -gt 0) { throw 'Nom de batch deja present. Aucun ecrasement.' }
$folder = New-M365ReportFolder -Name 'new-remote-move' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'plan' -Data @([pscustomobject]@{Name=$Name;Endpoint=$EndpointName;TargetDeliveryDomain=$TargetDeliveryDomain;Users=$rows.Count;AutoStart=$false;AutoComplete=$false})
Export-M365Report -Folder $folder -Name 'wave' -Data $rows
if ($Apply -and $PSCmdlet.ShouldProcess($Name,'Creer batch ExchangeRemoteMove sans demarrage')) {
    # Reconstruit un CSV minimal valide, evite les colonnes/encodages parasites du fichier source.
    $csv = ($rows | Select-Object EmailAddress | ConvertTo-Csv -NoTypeInformation) -join "`r`n"
    $batch = New-MigrationBatch -Name $Name -SourceEndpoint $EndpointName -TargetDeliveryDomain $TargetDeliveryDomain -CSVData ([Text.Encoding]::UTF8.GetBytes($csv)) -AutoStart:$false -AutoComplete:$false -ErrorAction Stop
    Export-M365Report -Folder $folder -Name 'created' -Data @($batch | Select-Object Identity,Status,MigrationType)
}
