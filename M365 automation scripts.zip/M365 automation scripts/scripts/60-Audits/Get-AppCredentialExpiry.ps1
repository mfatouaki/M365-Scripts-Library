<#
.SYNOPSIS
Echeances des certificats et secrets Entra ; jamais les valeurs des secrets.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [ValidateRange(1,3650)][int]$DaysAhead=60, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'app-credential-expiry' -OutputRoot $OutputRoot
$now = [datetimeoffset]::UtcNow
$limit = $now.AddDays($DaysAhead)
$apps = @(Get-M365GraphCollection -Uri '/v1.0/applications?$select=id,appId,displayName,passwordCredentials,keyCredentials')
$rows = @(foreach ($app in $apps) {
    foreach ($type in @('passwordCredentials','keyCredentials')) {
        foreach ($cred in @($app.$type)) {
            if (-not $cred.endDateTime) { continue }
            $expiry = [datetimeoffset]$cred.endDateTime
            if ($expiry -le $limit) {
                [pscustomobject]@{ObjectId=$app.id;AppId=$app.appId;DisplayName=$app.displayName;Kind=$type;KeyId=$cred.keyId;ExpiresUtc=$expiry.UtcDateTime.ToString('o');DaysRemaining=[math]::Floor(($expiry-$now).TotalDays);Expired=($expiry -lt $now)}
            }
        }
    }
})
Export-M365Report -Folder $folder -Name 'credentials' -Data $rows
