<#
.SYNOPSIS
Consentements OAuth delegues accordes aux applications d'entreprise.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'oauth-consents' -OutputRoot $OutputRoot
$rows = @(Get-M365GraphCollection -Uri '/v1.0/oauth2PermissionGrants')
Export-M365Report -Folder $folder -Name 'delegated-grants' -Data $rows
Write-Warning 'Les permissions applicatives appRoleAssignments ne sont pas incluses ; auditer avec Export-AppRoleAssignments.'
