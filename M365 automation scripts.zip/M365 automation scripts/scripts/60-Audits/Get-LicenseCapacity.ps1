<#
.SYNOPSIS
Capacite disponible par SKU ; consommation ponctuelle, pas facturation.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'license-capacity' -OutputRoot $OutputRoot
$rows = @(Get-M365GraphCollection -Uri '/v1.0/subscribedSkus' | ForEach-Object {
    [pscustomobject]@{SkuId=$_.skuId;SkuPartNumber=$_.skuPartNumber;Status=$_.capabilityStatus;Enabled=$_.prepaidUnits.enabled;Consumed=$_.consumedUnits;Available=([int]$_.prepaidUnits.enabled-[int]$_.consumedUnits);Suspended=$_.prepaidUnits.suspended;Warning=$_.prepaidUnits.warning}
})
Export-M365Report -Folder $folder -Name 'capacity' -Data $rows
