<#
.SYNOPSIS
Boites avec transfert SMTP configure ; regles Inbox non couvertes.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'mail-forwarding' -OutputRoot $OutputRoot
$rows = @(Get-EXOMailbox -ResultSize Unlimited -Properties ForwardingSmtpAddress,ForwardingAddress,DeliverToMailboxAndForward -ErrorAction Stop |
    Where-Object { $_.ForwardingSmtpAddress -or $_.ForwardingAddress } |
    Select-Object UserPrincipalName,PrimarySmtpAddress,ForwardingSmtpAddress,ForwardingAddress,DeliverToMailboxAndForward)
Export-M365Report -Folder $folder -Name 'forwarding-review' -Data $rows
Write-Warning 'La destination peut etre interne. Comparer aux domaines acceptes ; auditer aussi les regles Inbox et les regles de transport.'
