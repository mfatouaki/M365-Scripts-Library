<#
.SYNOPSIS
Regles Inbox avec transfert/redirection sur les boites selectionnees.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [Parameter(Mandatory)][string]$CsvPath, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Exchange -TenantId $TenantId
$inputs = @(Import-M365Csv -Path $CsvPath -RequiredColumns UserPrincipalName -UniqueColumn UserPrincipalName)
$folder = New-M365ReportFolder -Name 'inbox-forwarding' -OutputRoot $OutputRoot
$rows = @(foreach ($r in $inputs) {
    Get-InboxRule -Mailbox $r.UserPrincipalName -IncludeHidden -ErrorAction Stop |
        Where-Object { $_.ForwardTo -or $_.RedirectTo -or $_.ForwardAsAttachmentTo } |
        Select-Object @{n='Mailbox';e={$r.UserPrincipalName}},Identity,Name,Enabled,Priority,ForwardTo,RedirectTo,ForwardAsAttachmentTo,DeleteMessage,StopProcessingRules
})
Export-M365Report -Folder $folder -Name 'rules' -Data $rows
