<#
.SYNOPSIS
Candidats invites inactifs, pour revue humaine uniquement. Aucune suppression.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [ValidateRange(30,3650)][int]$InactiveDays=180, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'guest-review' -OutputRoot $OutputRoot
$limit = [datetimeoffset]::UtcNow.AddDays(-$InactiveDays)
$guests = @(Get-M365GraphCollection -Uri '/v1.0/users?$filter=userType%20eq%20%27Guest%27&$select=id,displayName,userPrincipalName,accountEnabled,createdDateTime,signInActivity&$top=500')
$rows = @(foreach ($g in $guests) {
    $last = $null
    if ($g.signInActivity -and $g.signInActivity.PSObject.Properties['lastSuccessfulSignInDateTime']) { $last=$g.signInActivity.lastSuccessfulSignInDateTime }
    if (-not $last -or [datetimeoffset]$last -lt $limit) {
        [pscustomobject]@{Id=$g.id;UserPrincipalName=$g.userPrincipalName;DisplayName=$g.displayName;CreatedUtc=$g.createdDateTime;Enabled=$g.accountEnabled;LastSuccessfulSignInUtc=$last;Evidence=$(if($last){'OlderThanThreshold'}else{'UnknownNoHistory'});Action='HumanReviewOnly'}
    }
})
Export-M365Report -Folder $folder -Name 'candidates' -Data $rows
Write-Warning 'Historique absent = inconnu, pas inactif. Verifier creation recente, proprietaire, acces indirect, besoins metier et retention. Aucune suppression automatique.'
