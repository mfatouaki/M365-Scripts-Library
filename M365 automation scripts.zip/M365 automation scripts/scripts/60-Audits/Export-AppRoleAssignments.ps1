<#
.SYNOPSIS
Permissions applicatives des service principals, a resoudre contre leurs appRoles.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'app-role-assignments' -OutputRoot $OutputRoot
$principals = @(Get-M365GraphCollection -Uri '/v1.0/servicePrincipals?$select=id,appId,displayName,appRoles')
Export-M365Report -Folder $folder -Name 'principals-and-role-definitions' -Data $principals
$rows = @(foreach ($sp in $principals) {
    foreach ($assignment in @(Get-M365GraphCollection -Uri "/v1.0/servicePrincipals/$($sp.id)/appRoleAssignments")) {
        [pscustomobject]@{ClientId=$sp.id;ClientAppId=$sp.appId;ClientName=$sp.displayName;ResourceId=$assignment.resourceId;AppRoleId=$assignment.appRoleId;AssignmentId=$assignment.id;CreatedUtc=$assignment.createdDateTime}
    }
})
Export-M365Report -Folder $folder -Name 'application-grants' -Data $rows
