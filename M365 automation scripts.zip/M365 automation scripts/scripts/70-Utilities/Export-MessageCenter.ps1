<#
.SYNOPSIS
Annonces Message Center pour veille des changements.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'message-center' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'messages' -Data @(Get-M365GraphCollection -Uri '/v1.0/admin/serviceAnnouncement/messages')
