<#
.SYNOPSIS
Incidents et etat de sante des services M365.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][guid]$TenantId, [string]$OutputRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Context -Service Graph -TenantId $TenantId
$folder = New-M365ReportFolder -Name 'service-health' -OutputRoot $OutputRoot
Export-M365Report -Folder $folder -Name 'overview' -Data @(Get-M365GraphCollection -Uri '/v1.0/admin/serviceAnnouncement/healthOverviews')
Export-M365Report -Folder $folder -Name 'issues' -Data @(Get-M365GraphCollection -Uri '/v1.0/admin/serviceAnnouncement/issues')
