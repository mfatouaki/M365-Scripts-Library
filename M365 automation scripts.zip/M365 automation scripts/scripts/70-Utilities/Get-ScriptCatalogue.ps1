<#
.SYNOPSIS
Recherche locale dans le catalogue ; n'execute pas les scripts.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([string]$Search, [string]$Service, [string]$Mode, [switch]$AsJson)
$ErrorActionPreference = 'Stop'
$path = Join-Path $PSScriptRoot '../../catalog/scripts.json'
$parsed = Get-Content -LiteralPath $path -Raw -Encoding utf8 | ConvertFrom-Json
$rows = @($parsed)
if ($Search) { $rows = @($rows | Where-Object { ($_.Path+' '+$_.Description+' '+$_.Permissions).IndexOf($Search,[StringComparison]::OrdinalIgnoreCase) -ge 0 }) }
if ($Service) { $rows = @($rows | Where-Object Service -eq $Service) }
if ($Mode) { $rows = @($rows | Where-Object Mode -eq $Mode) }
if ($AsJson) { ConvertTo-Json -InputObject $rows -Depth 5 } else { $rows | Select-Object Id,Path,Description,Service,Mode }
