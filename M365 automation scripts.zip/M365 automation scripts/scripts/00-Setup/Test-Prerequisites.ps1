<#
.SYNOPSIS
Controle local de PowerShell, modules et commandes. Aucune installation.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([string]$OutputRoot)
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
$folder = New-M365ReportFolder -Name 'prerequisites' -OutputRoot $OutputRoot
$rows = @([pscustomobject]@{Component='PowerShell';Version=$PSVersionTable.PSVersion.ToString();Available=($PSVersionTable.PSVersion -ge [version]'7.4')})
foreach ($name in @('Microsoft.Graph.Authentication','ExchangeOnlineManagement','MicrosoftTeams','PnP.PowerShell','ActiveDirectory')) {
    $m = Get-Module -ListAvailable -Name $name | Sort-Object Version -Descending | Select-Object -First 1
    $rows += [pscustomobject]@{Component=$name;Version=$(if($m){$m.Version.ToString()}else{''});Available=([bool]$m)}
}
Export-M365Report -Folder $folder -Name 'modules' -Data $rows
$rows | Format-Table -AutoSize
