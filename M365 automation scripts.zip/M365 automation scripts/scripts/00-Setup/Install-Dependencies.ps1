<#
.SYNOPSIS
Installe les modules admin en CurrentUser, apres confirmation. Ne modifie pas le tenant.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding(SupportsShouldProcess,ConfirmImpact='High')]
param([switch]$Apply, [string[]]$Modules=@('Microsoft.Graph.Authentication','ExchangeOnlineManagement','MicrosoftTeams','PnP.PowerShell'))
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime
$allowed = @('Microsoft.Graph.Authentication','ExchangeOnlineManagement','MicrosoftTeams','PnP.PowerShell','Pester','PSScriptAnalyzer')
foreach ($name in $Modules) { if ($name -notin $allowed) { throw "Module non autorise : $name" } }
foreach ($name in $Modules) {
    if (-not $Apply) { Write-Host "PLAN : installer $name depuis PSGallery en CurrentUser"; continue }
    if ($PSCmdlet.ShouldProcess($name,'Installer depuis PSGallery (dependances incluses)')) {
        Install-Module -Name $name -Repository PSGallery -Scope CurrentUser -ErrorAction Stop
    }
}
