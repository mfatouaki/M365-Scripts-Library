<#
.SYNOPSIS
Connexion interactive a un service. Dot-sourcer dans la console qui executera les scripts.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('Graph','Exchange','Teams','PnP')][string]$Service,
      [Parameter(Mandatory)][guid]$TenantId, [string[]]$Scopes,
      [uri]$Url, [guid]$ClientId)
Import-Module "$PSScriptRoot/../../modules/M365.Common.psm1" -Force
Assert-M365Runtime
if ($TenantId -eq [guid]::Empty) { throw 'TenantId exemple interdit.' }
switch ($Service) {
    'Graph' {
        if (-not $Scopes) { throw 'Indiquer les scopes minimaux du catalogue.' }
        Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
        Connect-MgGraph -TenantId $TenantId -Scopes $Scopes -ContextScope Process -NoWelcome -ErrorAction Stop
        Assert-M365Context -Service Graph -TenantId $TenantId
    }
    'Exchange' {
        Import-Module ExchangeOnlineManagement -ErrorAction Stop
        Connect-ExchangeOnline -Organization ([string]$TenantId) -ShowBanner:$false -ErrorAction Stop
        Assert-M365Context -Service Exchange -TenantId $TenantId
    }
    'Teams' {
        Import-Module MicrosoftTeams -ErrorAction Stop
        $null = Connect-MicrosoftTeams -TenantId $TenantId -ErrorAction Stop
        Assert-M365Context -Service Teams -TenantId $TenantId
    }
    'PnP' {
        if (-not $Url -or -not $ClientId -or $ClientId -eq [guid]::Empty) { throw 'URL et ClientId de votre application Entra requis pour PnP.' }
        Import-Module PnP.PowerShell -ErrorAction Stop
        Connect-PnPOnline -Url $Url.AbsoluteUri -Tenant ([string]$TenantId) -ClientId ([string]$ClientId) -Interactive -ErrorAction Stop
        Assert-PnPUrl -Url $Url
    }
}
