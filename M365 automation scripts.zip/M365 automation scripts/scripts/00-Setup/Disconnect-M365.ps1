<#
.SYNOPSIS
Ferme uniquement les sessions de cette console.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('Graph','Exchange','Teams','PnP')][string[]]$Service)
foreach ($item in $Service) {
    switch ($item) {
        'Graph' { $null = Disconnect-MgGraph -ErrorAction Stop }
        'Exchange' { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction Stop }
        'Teams' { $null = Disconnect-MicrosoftTeams -ErrorAction Stop }
        'PnP' { Disconnect-PnPOnline -ErrorAction Stop }
    }
}
