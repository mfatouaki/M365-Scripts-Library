# References officielles pour qualification

Liens de reference pour verifier les prerequis et le comportement live. Verification documentaire ciblee le 26 novembre 2026 des pages New-MigrationBatch (syntaxe RemoteMove onboarding) et Get-MigrationUserStatistics (compteur SkippedItemCount). Le reste n'a pas fait l'objet d'une validation exhaustive en ligne. Aucune certification tenant. Toujours controler les versions supportees, licences, limitations et schemas Microsoft en vigueur avant execution.

- [Microsoft Graph PowerShell - installation](https://learn.microsoft.com/powershell/microsoftgraph/installation)
- [Permissions Microsoft Graph](https://learn.microsoft.com/graph/permissions-reference)
- [Pagination Graph](https://learn.microsoft.com/graph/paging)
- [Throttling Graph](https://learn.microsoft.com/graph/throttling)
- [Affecter des licences](https://learn.microsoft.com/graph/api/user-assignlicense?view=graph-rest-1.0)
- [Connexion Exchange Online PowerShell](https://learn.microsoft.com/powershell/exchange/connect-to-exchange-online-powershell)
- [New-MigrationBatch](https://learn.microsoft.com/powershell/module/exchangepowershell/new-migrationbatch)
- [Complete-MigrationBatch](https://learn.microsoft.com/powershell/module/exchangepowershell/complete-migrationbatch)
- [Get-MigrationUserStatistics](https://learn.microsoft.com/powershell/module/exchangepowershell/get-migrationuserstatistics)
- [Migrations Exchange hybrides](https://learn.microsoft.com/exchange/hybrid-deployment/move-mailboxes)
- [Cross-tenant mailbox migration](https://learn.microsoft.com/exchange/mailbox-migration/cross-tenant-mailbox-migration)
- [Migration Manager](https://learn.microsoft.com/sharepointmigration/mm-get-started)
- [SharePoint Migration Tool](https://learn.microsoft.com/sharepointmigration/introducing-the-sharepoint-migration-tool)
- [Restrictions OneDrive/SharePoint](https://support.microsoft.com/office/64883a5d-228e-48f5-b3d2-eb39e07630fa)
- [PnP PowerShell - connexion](https://pnp.github.io/powershell/cmdlets/Connect-PnPOnline.html)
- [PnP tenant sites](https://pnp.github.io/powershell/cmdlets/Get-PnPTenantSite.html)
- [Microsoft Teams PowerShell](https://learn.microsoft.com/microsoftteams/teams-powershell-install)
- [Microsoft 365 service communications API](https://learn.microsoft.com/graph/api/resources/service-communications-api-overview?view=graph-rest-1.0)

Les permissions du catalogue ne sont pas accordees automatiquement. Elles doivent etre confirmees pour le contexte delegue et votre tenant. Les modules n'ont pas ete installes ni connectes pendant la creation.
