# Validation de livraison - 26 novembre 2026

## Resultats locaux

- 55 scripts catalogues, 11 templates CSV, module commun et deux scripts de test.
- 238 controles statiques passes : 58 fichiers PowerShell parses (55 scripts, 2 tests et 1 module), 12 controles de garde-fous de mutation, 55 controles d'aide, 110 controles de couverture/cibles du catalogue, 1 controle de nombre/doublons et 2 validations JSON.
- 31 tests offline passes : pagination Graph, rejet d'un autre hote, boucle de pagination, chemins API, encodage, serialisation JSON, retry GET 503 sans attendre (sleep simule), absence de retry d'ecriture, runtime, tenant/URL attendus, CSV, rapports, simulation et prevalidation complete.
- La simulation ShouldProcess refuse les executions distantes et les rapports locaux restent disponibles meme avec WhatIf.
- Recherche du catalogue par mot migration testee. Aide Get-Help testee sur le script de licences.

## Environnement et limites

Execution locale des tests via Windows PowerShell 5.1, seul hote PowerShell present. Les scripts d'administration exigent PowerShell 7.4+ et les versions minimales propres aux modules (notamment PnP). Le garde-fou de runtime est teste, puis neutralise uniquement dans le processus de test pour les tests de contexte sous 5.1.

Toutes les requetes Graph des tests sont simulees. Les services Microsoft, les roles/consentements, les modules M365, les licences et la propagation asynchrone n'ont PAS ete testes sur un tenant reel. Aucun module M365 n'a ete installe ni aucune connexion cloud d'administration ouverte. La verification de documentation publique Exchange est ciblee, pas exhaustive.

Ces tests ne constituent pas une validation de production. Avant production : installer PowerShell 7 et modules approuves, rejouer les tests, verifier les schemas/parametres avec les modules effectivement deployes et executer un pilote avec revue des rapports et autorisations minimales.

## Rejouer

```powershell
./tests/Test-Library.ps1
./tests/Test-Offline.ps1
```

Les tests creent des rapports locaux, jamais de donnees dans le tenant. Chaque processus de test doit etre dedie ; ne pas dot-sourcer Test-Offline dans une console admin connectee, car il remplace des fonctions du module charge par des mocks dans ce processus.

La copie de livraison controle chaque fichier par SHA256 et refuse d'ecraser un fichier existant.
