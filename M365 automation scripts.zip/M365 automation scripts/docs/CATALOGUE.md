# Catalogue des 55 scripts

Base locale : `catalog/scripts.json` et `catalog/scripts.csv`. Interroger avec `./scripts/70-Utilities/Get-ScriptCatalogue.ps1 -Search migration` ou `-Service Graph -Mode Lecture`. Consulter l'aide d'un script avec `Get-Help ./scripts/.../Nom.ps1` et ses parametres avec `Get-Command ./scripts/.../Nom.ps1 -Syntax`.

Tous les scripts distants attendent une connexion preexistante dans la meme console, et verifient le tenant (Graph/Exchange/Teams) ou l'URL PnP. Les permissions ci-dessous sont des points de depart : role RBAC, consentement, licences et politiques peuvent restreindre le resultat. Les exports ne sont pas des backups restaurables.

| Script | Usage | Service | Permissions / prerequis | Mode |
|---|---|---|---|---|
| [Test-Prerequisites.ps1](../scripts/00-Setup/Test-Prerequisites.ps1) | Controle PowerShell et modules locaux. | Local/Connexion | Selon service ; installation en CurrentUser | Lecture |
| [Install-Dependencies.ps1](../scripts/00-Setup/Install-Dependencies.ps1) | Installation de modules PSGallery CurrentUser, sans installation automatique a la livraison. | Local/Connexion | Selon service ; installation en CurrentUser | Ecriture locale protegee |
| [Connect-M365.ps1](../scripts/00-Setup/Connect-M365.ps1) | Connexion interactive explicite a un service, a dot-sourcer. | Local/Connexion | Selon service ; installation en CurrentUser | Connexion |
| [Disconnect-M365.ps1](../scripts/00-Setup/Disconnect-M365.ps1) | Deconnexion des sessions de la console. | Local/Connexion | Selon service ; installation en CurrentUser | Deconnexion |
| [Export-EntraUsers.ps1](../scripts/10-Discovery/Export-EntraUsers.ps1) | Inventaire utilisateurs, synchronisation, licences et plans de service. | Graph | User.Read.All | Lecture |
| [Export-TenantDomains.ps1](../scripts/10-Discovery/Export-TenantDomains.ps1) | Organisation et domaines verifies, type de federation. | Graph | Domain.Read.All + Organization.Read.All | Lecture |
| [Export-LicenseInventory.ps1](../scripts/10-Discovery/Export-LicenseInventory.ps1) | SKU souscrits, capacites et consommation declaree. | Graph | Organization.Read.All | Lecture |
| [Export-EntraGroups.ps1](../scripts/10-Discovery/Export-EntraGroups.ps1) | Groupes, types, regles dynamiques et proprietes de synchronisation. | Graph | Group.Read.All | Lecture |
| [Export-EntraDevices.ps1](../scripts/10-Discovery/Export-EntraDevices.ps1) | Objets appareils Entra ; ce n'est pas un inventaire Intune. | Graph | Device.Read.All | Lecture |
| [Export-ConditionalAccess.ps1](../scripts/10-Discovery/Export-ConditionalAccess.ps1) | Politiques Conditional Access, sans les modifier. | Graph | Policy.Read.All | Lecture |
| [Export-AppRegistrations.ps1](../scripts/10-Discovery/Export-AppRegistrations.ps1) | Applications et metadonnees de certificats/secrets ; pas leurs valeurs. | Graph | Application.Read.All | Lecture |
| [Export-ServicePrincipals.ps1](../scripts/10-Discovery/Export-ServicePrincipals.ps1) | Applications d'entreprise et statut, sans extraire de tokens. | Graph | Application.Read.All | Lecture |
| [Export-AuthenticationRegistration.ps1](../scripts/10-Discovery/Export-AuthenticationRegistration.ps1) | Rapport d'enregistrement MFA/SSPR ; pas une preuve de MFA imposee. | Graph | AuditLog.Read.All (role Reports Reader + licence selon Microsoft) | Lecture |
| [Export-DirectoryRoles.ps1](../scripts/10-Discovery/Export-DirectoryRoles.ps1) | Affectations de roles actives (hors eligibilites PIM). | Graph | RoleManagement.Read.Directory | Lecture |
| [Export-GroupMembers.ps1](../scripts/10-Discovery/Export-GroupMembers.ps1) | Membres directs de groupes selectionnes. | Graph | GroupMember.Read.All ; Member.Read.Hidden pour membres caches ; droits type pour details | Lecture |
| [Export-SignInLogs.ps1](../scripts/10-Discovery/Export-SignInLogs.ps1) | Connexions sur une fenetre UTC bornee. | Graph | AuditLog.Read.All ; licence Entra/retention et role adapte | Lecture |
| [Export-ExchangeMailboxes.ps1](../scripts/10-Discovery/Export-ExchangeMailboxes.ps1) | Boites aux lettres, tailles, archivage, retention et limites. | Exchange | View-Only Recipients + droits Get-EXOMailboxStatistics | Lecture |
| [Export-MailboxPermissions.ps1](../scripts/10-Discovery/Export-MailboxPermissions.ps1) | FullAccess, SendAs et SendOnBehalf sur les boites selectionnees. | Exchange | View-Only Recipients + droits Get-MailboxPermission/Get-RecipientPermission | Lecture |
| [Export-MailFlowConfiguration.ps1](../scripts/10-Discovery/Export-MailFlowConfiguration.ps1) | Domaines acceptes, connecteurs et regles de transport ; export documentaire. | Exchange | View-Only Configuration + droits lecture regles/connecteurs | Lecture |
| [Export-MigrationStatus.ps1](../scripts/10-Discovery/Export-MigrationStatus.ps1) | Etat des batches et utilisateurs de migration Exchange, sans contenu des messages. | Exchange | Migration (lecture) | Lecture |
| [Export-TeamsInventory.ps1](../scripts/10-Discovery/Export-TeamsInventory.ps1) | Equipes visibles par le compte et canaux ; ne recense pas les chats. | Teams | Teams Administrator ou visibilite limitee au compte | Lecture |
| [Export-TeamsPolicies.ps1](../scripts/10-Discovery/Export-TeamsPolicies.ps1) | Politiques de reunion, messagerie et federation ; definitions seulement. | Teams | Teams Administrator (lecture) | Lecture |
| [Export-SharePointSites.ps1](../scripts/10-Discovery/Export-SharePointSites.ps1) | Sites SharePoint/OneDrive, quotas et partage. | PnP | SharePoint Administrator ; app PnP deleguee et consentement approprie | Lecture |
| [Export-SharePointLibraries.ps1](../scripts/10-Discovery/Export-SharePointLibraries.ps1) | Bibliotheques documentaires d'un site et versioning. | PnP | Lecture du site via application PnP deleguee | Lecture |
| [Test-IdentityMapping.ps1](../scripts/20-Readiness/Test-IdentityMapping.ps1) | Syntaxe et doublons du mapping d'identites. | Local | Aucun | Lecture |
| [Test-MigrationWave.ps1](../scripts/20-Readiness/Test-MigrationWave.ps1) | Validation d'une vague Exchange RemoteMove. | Local | Aucun | Lecture |
| [Export-OnPremADUsers.ps1](../scripts/20-Readiness/Export-OnPremADUsers.ps1) | Inventaire Active Directory source. | AD/RSAT | Lecture de l'OU ; serveur et SearchBase explicites | Lecture |
| [Test-DomainDns.ps1](../scripts/20-Readiness/Test-DomainDns.ps1) | Observation DNS mail avant/apres bascule. | Local/DNS | Resolve-DnsName Windows ; acces DNS | Lecture |
| [Test-FileShareReadiness.ps1](../scripts/20-Readiness/Test-FileShareReadiness.ps1) | Precontrole chemins/noms/tailles des fichiers source. | Local | Lecture du partage ; ACL, reparse points et limitations SPMT a analyser separément | Lecture |
| [Test-TargetUsers.ps1](../scripts/20-Readiness/Test-TargetUsers.ps1) | Verification des utilisateurs cibles. | Graph | User.Read.All | Lecture |
| [New-MigrationWaves.ps1](../scripts/20-Readiness/New-MigrationWaves.ps1) | Generation de vagues CSV locales. | Local | Aucun | Lecture |
| [Compare-CsvSnapshots.ps1](../scripts/50-Validation/Compare-CsvSnapshots.ps1) | Comparaison avant/apres par cle unique. | Local | Aucun ; snapshots non vides et meme schema | Lecture |
| [Set-UsageLocationFromCsv.ps1](../scripts/30-Administration/Set-UsageLocationFromCsv.ps1) | Definir UsageLocation a partir d'un CSV. | Graph | User.ReadWrite.All ; role User Administrator approprie | Ecriture protegee |
| [Set-UserLicensesFromCsv.ps1](../scripts/30-Administration/Set-UserLicensesFromCsv.ps1) | Ajouter des licences sans retrait. | Graph | LicenseAssignment.ReadWrite.All + User.Read.All + Organization.Read.All ; License Administrator | Ecriture protegee |
| [Add-GroupMembersFromCsv.ps1](../scripts/30-Administration/Add-GroupMembersFromCsv.ps1) | Ajouter des membres aux groupes cloud statiques. | Graph | GroupMember.ReadWrite.All + Group.Read.All + User.Read.All ; Groups Administrator ; Member.Read.Hidden si necessaire | Ecriture protegee |
| [Grant-MailboxDelegationFromCsv.ps1](../scripts/30-Administration/Grant-MailboxDelegationFromCsv.ps1) | Accorder FullAccess/SendAs, sans retrait. | Exchange | Mail Recipients/permissions delegates Exchange RBAC | Ecriture protegee |
| [Set-MailboxRegionalSettingsFromCsv.ps1](../scripts/30-Administration/Set-MailboxRegionalSettingsFromCsv.ps1) | Configurer langue et fuseau des boites. | Exchange | Mail Recipients ; fuseaux Windows sur poste Windows | Ecriture protegee |
| [Set-TeamsUserPoliciesFromCsv.ps1](../scripts/30-Administration/Set-TeamsUserPoliciesFromCsv.ps1) | Assigner des politiques Teams utilisateur existantes. | Teams | Teams Administrator ; assignations directes prioritaires aux groupes | Ecriture protegee |
| [Set-SharePointSiteQuotaFromCsv.ps1](../scripts/30-Administration/Set-SharePointSiteQuotaFromCsv.ps1) | Definir les quotas SharePoint (mode manuel). | PnP | SharePoint Administrator ; PnP tenant permissions | Ecriture protegee |
| [New-ExchangeRemoteMoveBatch.ps1](../scripts/40-Migration/New-ExchangeRemoteMoveBatch.ps1) | Creer un batch hybride Exchange sans demarrage. | Exchange | Migration RBAC ; hybride/HCW/MRSProxy et endpoint valides | Ecriture protegee |
| [Start-ExchangeMigrationBatch.ps1](../scripts/40-Migration/Start-ExchangeMigrationBatch.ps1) | Demarrer un batch hybride Exchange. | Exchange | Migration RBAC ; completion : bascule irreversible sans procedure specifique | Ecriture protegee |
| [Stop-ExchangeMigrationBatch.ps1](../scripts/40-Migration/Stop-ExchangeMigrationBatch.ps1) | Arreter la synchronisation de un batch hybride Exchange. | Exchange | Migration RBAC ; completion : bascule irreversible sans procedure specifique | Ecriture protegee |
| [Complete-ExchangeMigrationBatch.ps1](../scripts/40-Migration/Complete-ExchangeMigrationBatch.ps1) | Completer et basculer un batch hybride Exchange. | Exchange | Migration RBAC ; completion : bascule irreversible sans procedure specifique | Ecriture protegee |
| [Export-IntuneDevices.ps1](../scripts/10-Discovery/Export-IntuneDevices.ps1) | Appareils geres Intune et etat de conformite declare. | Graph | DeviceManagementManagedDevices.Read.All ; licence et role Intune | Lecture |
| [Get-AppCredentialExpiry.ps1](../scripts/60-Audits/Get-AppCredentialExpiry.ps1) | Secrets/certificats d'applications expirant prochainement. | Graph | Application.Read.All | Lecture |
| [Get-InactiveGuestCandidates.ps1](../scripts/60-Audits/Get-InactiveGuestCandidates.ps1) | Invites sans connexion reussie recente : candidats de revue. | Graph | User.Read.All + AuditLog.Read.All ; Entra P1/P2 pour signInActivity | Lecture |
| [Get-LicenseCapacity.ps1](../scripts/60-Audits/Get-LicenseCapacity.ps1) | Capacite disponible des licences par SKU. | Graph | Organization.Read.All | Lecture |
| [Get-ExternalMailboxForwarding.ps1](../scripts/60-Audits/Get-ExternalMailboxForwarding.ps1) | Transferts mailbox configures a analyser. | Exchange | View-Only Recipients | Lecture |
| [Get-InboxForwardingRules.ps1](../scripts/60-Audits/Get-InboxForwardingRules.ps1) | Regles Inbox avec transfert ou redirection. | Exchange | RBAC Get-InboxRule ; droits de lecture boites | Lecture |
| [Get-OAuthConsentGrants.ps1](../scripts/60-Audits/Get-OAuthConsentGrants.ps1) | Consentements OAuth delegues. | Graph | DelegatedPermissionGrant.Read.All | Lecture |
| [Export-AppRoleAssignments.ps1](../scripts/60-Audits/Export-AppRoleAssignments.ps1) | Permissions applicatives et definitions de roles. | Graph | Application.Read.All ; N+1 appels, surveiller throttling | Lecture |
| [Test-MigratedMailboxes.ps1](../scripts/50-Validation/Test-MigratedMailboxes.ps1) | Verification technique des boites apres migration. | Exchange | View-Only Recipients + Get-EXOMailboxStatistics | Lecture |
| [Export-ServiceHealth.ps1](../scripts/70-Utilities/Export-ServiceHealth.ps1) | Sante des services et incidents Microsoft. | Graph | ServiceHealth.Read.All ; role Service Support/Global Reader selon acces | Lecture |
| [Export-MessageCenter.ps1](../scripts/70-Utilities/Export-MessageCenter.ps1) | Veille des changements Message Center. | Graph | ServiceMessage.Read.All ; role de lecture adapte | Lecture |
| [Get-ScriptCatalogue.ps1](../scripts/70-Utilities/Get-ScriptCatalogue.ps1) | Recherche dans la base locale des scripts sans les executer. | Local | Aucun | Lecture |

## Templates CSV

Separateur virgule, UTF-8, en-tetes inchanges. Remplacer toutes les valeurs d'exemple. Semicolon reserve aux champs multivaleurs exportes ; les CSV d'entree ne prennent pas plusieurs utilisateurs/SKU dans une cellule.

| Template | Scripts |
|---|---|
| identity-mapping.csv | Test-IdentityMapping |
| users.csv | Test-TargetUsers, Test-MigratedMailboxes, Export-MailboxPermissions, Get-InboxForwardingRules |
| groups.csv | Export-GroupMembers |
| group-members.csv | Add-GroupMembersFromCsv |
| user-licenses.csv | Set-UserLicensesFromCsv (SkuId provenant d'Export-LicenseInventory) |
| usage-location.csv | Set-UsageLocationFromCsv |
| mailbox-delegation.csv | Grant-MailboxDelegationFromCsv |
| mailbox-regional.csv | Set-MailboxRegionalSettingsFromCsv |
| teams-policies.csv | Set-TeamsUserPoliciesFromCsv |
| sharepoint-quotas.csv | Set-SharePointSiteQuotaFromCsv |
| migration-wave.csv | Test-MigrationWave, New-MigrationWaves, New-ExchangeRemoteMoveBatch |

## Exemples pratiques

```powershell
# Decouverte tenant (apres connexion Graph avec les droits associes)
./scripts/10-Discovery/Export-LicenseInventory.ps1 -TenantId $tenant
./scripts/20-Readiness/Test-IdentityMapping.ps1 -CsvPath ./projet/mapping.csv
./scripts/20-Readiness/New-MigrationWaves.ps1 -CsvPath ./projet/migration.csv -WaveSize 25

# Hybride Exchange uniquement, connexion Exchange prealable
./scripts/40-Migration/New-ExchangeRemoteMoveBatch.ps1 -TenantId $tenant -Name Pilote01 -EndpointName HybridEndpoint -TargetDeliveryDomain contoso.mail.onmicrosoft.com -CsvPath ./projet/pilote.csv
./scripts/40-Migration/Start-ExchangeMigrationBatch.ps1 -TenantId $tenant -Name Pilote01 -Apply -WhatIf
./scripts/10-Discovery/Export-MigrationStatus.ps1 -TenantId $tenant

# Diff local de deux inventaires utilisateurs non vides
./scripts/50-Validation/Compare-CsvSnapshots.ps1 -BeforePath ./avant/inventory.csv -AfterPath ./apres/inventory.csv -KeyColumn id -Columns accountEnabled,usageLocation
```
