# Runbook projets M365

## 1. Cadrage et decision d'architecture

Documenter tenants source/cible, volumes, donnees sensibles, fuseaux, RTO/RPO, dependances applicatives, usages Teams, chemins SharePoint, retention/eDiscovery, planning, responsabilites et rollback. Enregistrer les decisions et approbations ; definir les criteres GO/NO-GO. Une politique de retention ou un hold ne doit pas etre retire pour faciliter une migration.

| Scenario | Parcours outille | Limites / decisions manuelles |
|---|---|---|
| Exchange on-premises hybride vers EXO | HCW + endpoint RemoteMove, scripts batch de cette bibliotheque | Certificats, MRSProxy, version Exchange supportee, federation/synchronisation, domaine routage, licences et connectivite |
| IMAP vers Exchange Online | Inventaires et mapping reutilisables ; outil IMAP choisi hors bibliotheque | Migration mail uniquement ; mots de passe source geres dans un coffre ; calendriers/contacts hors IMAP ; aucun CSV de secrets fourni |
| Tenant-to-tenant | Inventaires, mapping, vagues, verifications ; outils Microsoft cross-tenant ou solution qualifiee | Licences cross-tenant, trust/applications, holds, attributs cibles, domaine partage, ordonnancement DNS et coexistence ; pas un RemoteMove hybride |
| Partages vers SharePoint/OneDrive | Test-FileShareReadiness puis SPMT ou Migration Manager | Permissions cible, metadata, limites, fichiers verrouilles, delta, liens et versions ; ne pas utiliser Copy-Item comme moteur de migration |
| Teams/SharePoint tenant-to-tenant | Inventaire + projet specifique de migration supportee | Chats, canaux prives/partages, meetings/URLs, applications, etiquettes, groupes, versions et permissions ne sont pas transferes par les scripts d'inventaire |

## 2. Discovery et readiness

- Exporter utilisateurs/AD, groupes et membres selectionnes, licences, boites/statistiques/delegations, connecteurs/regles, Teams, sites et bibliotheques.
- Verifier scopes et couverture : un inventaire limite par les droits n'est pas un inventaire du tenant complet. Conserver chaque erreur.
- Construire mapping SourceUPN/TargetUPN, puis valider ; sourceAnchor reel selon Entra Connect/Cloud Sync, pas deduction automatique depuis ObjectGuid. Ne jamais forcer ImmutableId a partir d'un simple export.
- Verifier domaines, licences, UsageLocation, boites cibles et coexistence des identites. Corriger a la source les objets synchronises.
- Auditer taille/quota, archive, holds et retention. Calculer debit, deltas et fenetres de coupure. Tester DNS mais ne pas modifier automatiquement MX/DKIM/DMARC.
- Scinder les vagues et conserver les dependances : delegues, salles, VIP, groupes, applications et fuseaux. Le decoupage alphabetique fourni n'est qu'un point de depart.

## 3. Pilote et execution Exchange hybride

1. Valider HCW, version supportee Exchange, MRSProxy, endpoint et routage. Tester l'endpoint avec les outils Exchange officiels ; aucune creation d'endpoint contenant des identifiants n'est automatisee ici.
2. Exporter l'etat initial. Creer le batch avec le script New-ExchangeRemoteMoveBatch (plan, puis Apply).
3. Demarrer explicitement la synchronisation. Surveiller Export-MigrationStatus et erreurs individuelles. Les actions sont asynchrones.
4. Ne pas accepter des pertes de donnees pour passer en Synced : elements ignores ou erreurs imposent une analyse humaine. Aucun AcceptLargeDataLoss ni reglage de limite de mauvais elements automatique.
5. GO metier, support et technique documente, puis Complete-ExchangeMigrationBatch pour bascule. Le script bloque s'il detecte erreurs/elements ignores ; un blocage n'autorise pas leur contournement.
6. Verifier et attendre la completion reelle, puis controles ci-dessous. Ne pas supprimer les batches ni les donnees source automatiquement.

## 4. Validation et hypercare

Verifier connexion Web/Outlook/mobile, mail interne/externe dans les deux sens, rendez-vous, free/busy, delegation FullAccess/SendAs/SendOnBehalf, groupes, salles, archives, taille/nombre d'elements et echantillons, recherche, apps SMTP, retention et conformite. Pour fichiers : comparer nombre/taille/metadata, ouvrir des echantillons, verifier versioning, acces et liens. Pour Teams : verifier appartenance, canaux, acces externe et politiques effectives.

Comparer snapshots, rapprocher les anomalies et obtenir la recette metier. Tenir un journal d'incidents, surveiller service health et Message Center. Conserver l'ancien environnement selon les politiques approuvees ; decomissionnement et nettoyage ne sont pas couverts automatiquement.

## Rollback

Aucune transaction globale ni restauration automatique. Les plans contiennent des etats precedents pour analyse, pas un backup complet. Une completion Exchange, un changement DNS ou une migration de domaine peut exiger une migration inverse et de nouvelles operations. Definir les points de non-retour et faire valider le rollback AVANT le pilote. Une ligne Failed peut etre partiellement appliquee, notamment une double affectation Teams : reconcilier le cloud avant de relancer.

## Amelioration de service

Utiliser audits consentements, echeances d'applications, licences, transferts mail, enregistrement MFA, Conditional Access et partages comme observations. Prioriser avec le proprietaire du service. Ne pas desactiver des comptes, revoquer des consentements ou supprimer des policies a partir d'un seuil de rapport seul.
