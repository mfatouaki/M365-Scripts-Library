<#
.SYNOPSIS
Tests des fonctions communes, toutes requetes Graph simulees. Aucun module cloud requis.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([string]$OutputRoot=(Join-Path ([IO.Path]::GetTempPath()) ('m365-offline-'+[guid]::NewGuid().ToString('N'))))
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$module = Import-Module "$PSScriptRoot/../modules/M365.Common.psm1" -Force -PassThru
$null = New-Item -ItemType Directory -Path $OutputRoot -Force
$checks = [Collections.Generic.List[object]]::new()
function Check {
    param([string]$Name,[scriptblock]$Test)
    try { & $Test; $checks.Add([pscustomobject]@{Test=$Name;Passed=$true;Error=''}) }
    catch { $checks.Add([pscustomobject]@{Test=$Name;Passed=$false;Error=$_.Exception.Message}) }
}
function Require { param([bool]$Condition,[string]$Message='Assertion failed'); if (-not $Condition) { throw $Message } }
function Expect-Failure {
    param([scriptblock]$Action,[string]$Pattern)
    $failed=$false
    try { $null=& $Action } catch { $failed=$true; if ($Pattern) { Require ($_.Exception.Message -match $Pattern) 'Erreur differente de celle attendue.' } }
    Require $failed 'Une erreur etait attendue.'
}

# Injection uniquement dans le module charge par CE processus de test.
& $module {
    $script:MockCalls = [Collections.Generic.List[object]]::new()
    $script:SleepCalls = [Collections.Generic.List[int]]::new()
    function script:Start-Sleep { param([int]$Seconds); $script:SleepCalls.Add($Seconds) }
    function script:Invoke-MgGraphRequest {
        param($Method,$Uri,$OutputType,$ErrorAction,$Body,$ContentType)
        $script:MockCalls.Add([pscustomobject]@{Method=$Method;Uri=$Uri;Body=$Body})
        switch ($Uri) {
            '/v1.0/test' { return [pscustomobject]@{value=@([pscustomobject]@{id='1'});'@odata.nextLink'='https://graph.microsoft.com/v1.0/next'} }
            '/v1.0/next' { return [pscustomobject]@{value=@([pscustomobject]@{id='2'})} }
            '/v1.0/badnext' { return [pscustomobject]@{value=@();'@odata.nextLink'='https://untrusted.example/v1.0/next'} }
            '/v1.0/loop' { return [pscustomobject]@{value=@();'@odata.nextLink'='https://graph.microsoft.com/v1.0/loop'} }
            '/v1.0/empty' { return [pscustomobject]@{value=@()} }
            '/v1.0/notcollection' { return [pscustomobject]@{id='1'} }
            '/v1.0/write' { return [pscustomobject]@{ok=$true} }
            '/v1.0/failwrite' {
                $ex = [Exception]::new('Simulated uncertain write failure')
                $ex | Add-Member -MemberType NoteProperty -Name Response -Value ([pscustomobject]@{StatusCode=429})
                throw $ex
            }
            '/v1.0/retry' {
                if (@($script:MockCalls | Where-Object Uri -eq '/v1.0/retry').Count -eq 1) {
                    $ex = [Exception]::new('Simulated unavailable GET')
                    $ex | Add-Member -MemberType NoteProperty -Name Response -Value ([pscustomobject]@{StatusCode=503})
                    throw $ex
                }
                return [pscustomobject]@{value=@([pscustomobject]@{id='retried'})}
            }
            default { throw "Unexpected mock URI: $Uri" }
        }
    }
}
Check 'GraphPagination' { $r=@(Get-M365GraphCollection -Uri '/v1.0/test'); Require ($r.Count -eq 2 -and $r[1].id -eq '2') }
Check 'GraphEmpty' { Require (@(Get-M365GraphCollection -Uri '/v1.0/empty').Count -eq 0) }
Check 'GraphRejectForeignNextLink' { Expect-Failure { Get-M365GraphCollection -Uri '/v1.0/badnext' } -Pattern 'hors Graph' }
Check 'GraphRejectLoop' { Expect-Failure { Get-M365GraphCollection -Uri '/v1.0/loop' } -Pattern 'Boucle' }
Check 'GraphRejectMissingValue' { Expect-Failure { Get-M365GraphCollection -Uri '/v1.0/notcollection' } -Pattern 'collection' }
Check 'GraphRejectAbsoluteUri' { Expect-Failure { Invoke-M365Graph -Uri 'https://untrusted.example/v1.0/users' } }
Check 'GraphRejectBeta' { Expect-Failure { Invoke-M365Graph -Uri '/beta/users' } }
Check 'GraphEncodedSegment' { Require ((ConvertTo-M365Segment -Value 'user+a@contoso.com') -eq 'user%2Ba%40contoso.com') }
Check 'GraphJsonBody' {
    $null = Invoke-M365Graph -Uri '/v1.0/write' -Method POST -Body @{flag=$true;items=@()}
    $call = & $module { $script:MockCalls[$script:MockCalls.Count-1] }
    $body = $call.Body | ConvertFrom-Json
    Require ($body.flag -and @($body.items).Count -eq 0)
}
Check 'GraphWriteNotRetried' {
    $before = & $module { $script:MockCalls.Count }
    Expect-Failure { Invoke-M365Graph -Uri '/v1.0/failwrite' -Method POST -Body @{} }
    $after = & $module { $script:MockCalls.Count }
    Require (($after-$before) -eq 1)
}
Check 'GraphGetRetry503' {
    $rows = @(Get-M365GraphCollection -Uri '/v1.0/retry')
    Require ($rows.Count -eq 1 -and $rows[0].id -eq 'retried')
    $calls = & $module { @($script:MockCalls | Where-Object Uri -eq '/v1.0/retry').Count }
    Require ($calls -eq 2)
}
Check 'RuntimeGuard' {
    if ($PSVersionTable.PSVersion -lt [version]'7.4') { Expect-Failure { Assert-M365Runtime } -Pattern '7.4' }
    else { Assert-M365Runtime }
}
# Le runtime a ete teste ci-dessus. Neutralisation locale pour tester les contextes sous le parseur 5.1.
& $module {
    function script:Assert-M365Runtime { }
    function script:Get-MgContext { param($ErrorAction); [pscustomobject]@{TenantId='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'} }
    function script:Get-ConnectionInformation { param($ErrorAction); [pscustomobject]@{State='Connected';TenantID='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'} }
    function script:Get-CsTenant { param($ErrorAction); [pscustomobject]@{TenantId='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'} }
    function script:Get-PnPConnection { param($ErrorAction); [pscustomobject]@{Url='https://contoso.sharepoint.com/sites/pilote'} }
}
Check 'ContextExpectedTenant' {
    foreach ($s in @('Graph','Exchange','Teams')) { Assert-M365Context -Service $s -TenantId 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' }
}
Check 'ContextRejectWrongTenant' {
    foreach ($s in @('Graph','Exchange','Teams')) { Expect-Failure { Assert-M365Context -Service $s -TenantId 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' } }
}
Check 'ContextRejectPlaceholder' { Expect-Failure { Assert-M365Context -Service Graph -TenantId '00000000-0000-0000-0000-000000000000' } -Pattern 'exemple' }
Check 'PnPExpectedUrl' { Assert-PnPUrl -Url 'https://contoso.sharepoint.com/sites/pilote/' }
Check 'PnPRejectWrongUrl' { Expect-Failure { Assert-PnPUrl -Url 'https://other.sharepoint.com/sites/pilote' } -Pattern 'differente' }
Check 'PnPRejectHttp' { Expect-Failure { Assert-PnPUrl -Url 'http://contoso.sharepoint.com/sites/pilote' } -Pattern 'HTTPS' }
$csv = Join-Path $OutputRoot 'fixture.csv'
@([pscustomobject]@{UPN='a@contoso.com';Country='FR'},[pscustomobject]@{UPN='b@contoso.com';Country='GB'}) | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding utf8
Check 'CsvValid' { Require (@(Import-M365Csv -Path $csv -RequiredColumns UPN,Country -UniqueColumn UPN).Count -eq 2) }
Check 'CsvMissingColumn' { Expect-Failure { Import-M365Csv -Path $csv -RequiredColumns Missing } }
$dupCsv = Join-Path $OutputRoot 'duplicate.csv'
@([pscustomobject]@{UPN='a@contoso.com'},[pscustomobject]@{UPN='A@contoso.com'}) | Export-Csv -LiteralPath $dupCsv -NoTypeInformation -Encoding utf8
Check 'CsvDuplicate' { Expect-Failure { Import-M365Csv -Path $dupCsv -RequiredColumns UPN -UniqueColumn UPN } }
$blankCsv = Join-Path $OutputRoot 'blank.csv'
@([pscustomobject]@{UPN='a@contoso.com';Country=''}) | Export-Csv -LiteralPath $blankCsv -NoTypeInformation -Encoding utf8
Check 'CsvBlank' { Expect-Failure { Import-M365Csv -Path $blankCsv -RequiredColumns UPN,Country } }
Check 'ReportFolderUnique' {
    $a=New-M365ReportFolder -Name 'unique' -OutputRoot $OutputRoot
    $b=New-M365ReportFolder -Name 'unique' -OutputRoot $OutputRoot
    Require ($a -ne $b -and (Test-Path -LiteralPath $a) -and (Test-Path -LiteralPath $b))
}
Check 'ReportNameSafe' { Expect-Failure { New-M365ReportFolder -Name '../escape' -OutputRoot $OutputRoot } }
Check 'ReportNestedAndEmpty' {
    $f=New-M365ReportFolder -Name 'serialization' -OutputRoot $OutputRoot
    Export-M365Report -Folder $f -Name 'nested' -Data @([pscustomobject]@{Id='x';Nested=@{a=1}})
    $r=Import-Csv -LiteralPath (Join-Path $f 'nested.csv')
    Require (($r.Nested | ConvertFrom-Json).a -eq 1)
    Export-M365Report -Folder $f -Name 'empty' -Data @()
    Require (((Get-Content -LiteralPath (Join-Path $f 'empty.json') -Raw) -replace '\s','') -eq '[]')
}
$rows=@([pscustomobject]@{Target='a'},[pscustomobject]@{Target='b'})
Check 'ReportsPersistUnderWhatIf' {
    $f = & $module {
        param($root)
        $WhatIfPreference = $true
        $folder = New-M365ReportFolder -Name 'actual-whatif' -OutputRoot $root
        Export-M365Report -Folder $folder -Name 'plan' -Data @([pscustomobject]@{Target='local-only'})
        return $folder
    } $OutputRoot
    Require (Test-Path -LiteralPath (Join-Path $f 'plan.csv'))
    Require (Test-Path -LiteralPath (Join-Path $f 'plan.json'))
}
$caller=[pscustomobject]@{Allow=$true}
$caller | Add-Member -MemberType ScriptMethod -Name ShouldProcess -Value { param($Target,$Action); return $this.Allow }
$counter=@{Executed=0}
$validate={param($r); [pscustomobject]@{Target=$r.Target}}
$execute={param($p); $counter.Executed++}
Check 'ChangesPlanNoWrite' {
    $counter.Executed=0
    $f=New-M365ReportFolder -Name 'plan-only' -OutputRoot $OutputRoot
    Invoke-M365CsvChange -Caller $caller -Rows $rows -Folder $f -Action 'Test' -Validate $validate -Execute $execute
    Require ($counter.Executed -eq 0)
    Require (@(Import-Csv -LiteralPath (Join-Path $f 'results.csv') | Where-Object Status -ne 'Planned').Count -eq 0)
}
Check 'ChangesApplyWrites' {
    $counter.Executed=0; $caller.Allow=$true
    $f=New-M365ReportFolder -Name 'apply' -OutputRoot $OutputRoot
    Invoke-M365CsvChange -Caller $caller -Rows $rows -Folder $f -Action 'Test' -Validate $validate -Execute $execute -Apply
    Require ($counter.Executed -eq 2)
}
Check 'ChangesShouldProcessBlocks' {
    $counter.Executed=0; $caller.Allow=$false
    $f=New-M365ReportFolder -Name 'whatif' -OutputRoot $OutputRoot
    Invoke-M365CsvChange -Caller $caller -Rows $rows -Folder $f -Action 'Test' -Validate $validate -Execute $execute -Apply
    Require ($counter.Executed -eq 0)
}
Check 'ChangesWholeBatchPrevalidation' {
    $counter.Executed=0; $caller.Allow=$true
    $f=New-M365ReportFolder -Name 'reject-batch' -OutputRoot $OutputRoot
    Expect-Failure { Invoke-M365CsvChange -Caller $caller -Rows $rows -Folder $f -Action 'Test' -Validate {param($r); if($r.Target -eq 'b'){throw 'bad row'}; [pscustomobject]@{Target=$r.Target}} -Execute $execute -Apply }
    Require ($counter.Executed -eq 0)
}
Check 'ChangesFailureRecorded' {
    $caller.Allow=$true
    $f=New-M365ReportFolder -Name 'write-failure' -OutputRoot $OutputRoot
    Expect-Failure { Invoke-M365CsvChange -Caller $caller -Rows $rows -Folder $f -Action 'Test' -Validate $validate -Execute {param($p); throw 'simulated failure'} -Apply }
    $r=@(Import-Csv -LiteralPath (Join-Path $f 'results.csv'))
    Require ($r.Count -eq 2 -and @($r | Where-Object Status -ne 'Failed').Count -eq 0)
}
$checks.ToArray() | Export-Csv -LiteralPath (Join-Path $OutputRoot 'offline-test-results.csv') -NoTypeInformation -Encoding utf8
$checks | Format-Table -AutoSize
$failed=@($checks | Where-Object { -not $_.Passed })
if ($failed.Count -gt 0) { throw "$($failed.Count) tests offline echoues. Resultats : $OutputRoot" }
Write-Host "PASS : $($checks.Count) tests offline, aucun appel cloud. Resultats : $OutputRoot"
