<#
.SYNOPSIS
Validation statique sans connexion ni modules cloud. Compatible Windows PowerShell 5.1 pour le parseur uniquement.
.NOTES
Lire docs/CATALOGUE.md et docs/SECURITY.md. Tester sur un environnement pilote avant production.
#>
[CmdletBinding()]
param([string]$LibraryRoot, [string]$OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $LibraryRoot) { $LibraryRoot = Split-Path $PSScriptRoot -Parent }
$root = (Resolve-Path -LiteralPath $LibraryRoot).ProviderPath
$results = [Collections.Generic.List[object]]::new()
$files = @(Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object Extension -in @('.ps1','.psm1'))
foreach ($f in $files) {
    $tokens=$null; $parseErrors=$null
    $ast = [Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$tokens,[ref]$parseErrors)
    $results.Add([pscustomobject]@{Check='Syntax';File=$f.FullName.Substring($root.Length+1);Passed=($parseErrors.Count -eq 0);Details=(@($parseErrors | ForEach-Object Message) -join ';')})
    if ($f.Directory.Name -in @('30-Administration','40-Migration') -or $f.Name -eq 'Install-Dependencies.ps1') {
        $hasApply = @($ast.ParamBlock.Parameters | Where-Object { $_.Name.VariablePath.UserPath -eq 'Apply' }).Count -eq 1
        # Lecture simple : verification SupportsShouldProcess et invocation du garde-fou direct ou commun.
        $source = Get-Content -LiteralPath $f.FullName -Raw -Encoding utf8
        $guarded = $source -match 'SupportsShouldProcess' -and $source -match '\.ShouldProcess\s*\(|\bInvoke-M365CsvChange\b'
        $results.Add([pscustomobject]@{Check='MutationGuard';File=$f.Name;Passed=($hasApply -and $guarded);Details='Apply + SupportsShouldProcess + execution protegee'})
    }
}
$parsedCatalog = Get-Content -LiteralPath (Join-Path $root 'catalog/scripts.json') -Raw -Encoding utf8 | ConvertFrom-Json
$catalog = @($parsedCatalog)
$scriptFiles = @(Get-ChildItem -LiteralPath (Join-Path $root 'scripts') -Recurse -File -Filter '*.ps1')
$paths = @($catalog | ForEach-Object Path)
foreach ($f in $scriptFiles) {
    $rel = $f.FullName.Substring($root.Length+1).Replace('\','/')
    $results.Add([pscustomobject]@{Check='CatalogCoverage';File=$rel;Passed=($rel -in $paths);Details=''})
    $source = Get-Content -LiteralPath $f.FullName -Raw -Encoding utf8
    $results.Add([pscustomobject]@{Check='HelpSynopsis';File=$rel;Passed=($source -match '(?m)^\.SYNOPSIS\s*$');Details='Aide integree'})
}
foreach ($entry in $catalog) {
    $exists = Test-Path -LiteralPath (Join-Path $root $entry.Path) -PathType Leaf
    $results.Add([pscustomobject]@{Check='CatalogTarget';File=$entry.Path;Passed=$exists;Details=''})
}
$dup = @($paths | Group-Object | Where-Object Count -gt 1)
$results.Add([pscustomobject]@{Check='CatalogCount';File='catalog/scripts.json';Passed=($scriptFiles.Count -eq $catalog.Count -and $dup.Count -eq 0);Details="$($scriptFiles.Count) scripts, $($catalog.Count) entrees"})
foreach ($json in @(Get-ChildItem -LiteralPath $root -Recurse -File -Filter '*.json')) {
    try { $null = Get-Content -LiteralPath $json.FullName -Raw -Encoding utf8 | ConvertFrom-Json; $valid=$true } catch { $valid=$false }
    $results.Add([pscustomobject]@{Check='JsonSyntax';File=$json.Name;Passed=$valid;Details=''})
}
$results | Group-Object Check | Select-Object Name,Count | Format-Table -AutoSize
if ($OutputPath) { $results.ToArray() | Export-Csv -LiteralPath $OutputPath -NoTypeInformation -Encoding utf8 }
$failed = @($results | Where-Object { -not $_.Passed })
if ($failed.Count -gt 0) { $failed | Format-Table -AutoSize; throw "$($failed.Count) controles statiques echoues." }
Write-Host "PASS : $($results.Count) controles statiques. Aucun appel cloud."
