Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Assert-M365Runtime {
    if ($PSVersionTable.PSVersion -lt [version]'7.4') { throw 'PowerShell 7.4+ requis. Ouvrez pwsh, pas Windows PowerShell 5.1.' }
}

function Assert-M365Context {
    [CmdletBinding()]
    param([Parameter(Mandatory)][ValidateSet('Graph','Exchange','Teams')][string]$Service,
          [Parameter(Mandatory)][guid]$TenantId)
    Assert-M365Runtime
    if ($TenantId -eq [guid]::Empty) { throw 'Remplacer le TenantId exemple par le tenant reel.' }
    switch ($Service) {
        'Graph' {
            $ctx = Get-MgContext -ErrorAction Stop
            if (-not $ctx -or [string]$ctx.TenantId -ne [string]$TenantId) { throw 'Contexte Graph absent ou tenant incorrect. Reconnectez-vous explicitement.' }
        }
        'Exchange' {
            $connections = @(Get-ConnectionInformation -ErrorAction Stop | Where-Object { $_.State -eq 'Connected' })
            if ($connections.Count -ne 1 -or [string]$connections[0].TenantID -ne [string]$TenantId) { throw 'Une seule connexion Exchange active au tenant attendu est requise.' }
        }
        'Teams' {
            $ctx = Get-CsTenant -ErrorAction Stop
            if ([string]$ctx.TenantId -ne [string]$TenantId) { throw 'Tenant Teams incorrect.' }
        }
    }
}

function Assert-PnPUrl {
    [CmdletBinding()]
    param([Parameter(Mandatory)][uri]$Url)
    Assert-M365Runtime
    if ($Url.Scheme -ne 'https') { throw 'URL HTTPS requise.' }
    $ctx = Get-PnPConnection -ErrorAction Stop
    if (-not $ctx -or ([string]$ctx.Url).TrimEnd('/') -ine $Url.AbsoluteUri.TrimEnd('/')) { throw 'Connexion PnP absente ou URL differente. Reconnectez-vous a cette URL exacte.' }
}

function New-M365ReportFolder {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Name, [string]$OutputRoot)
    if (-not $OutputRoot) { $OutputRoot = Join-Path (Split-Path $PSScriptRoot -Parent) 'reports' }
    if ($Name -notmatch '^[A-Za-z0-9-]+$') { throw 'Nom de rapport invalide.' }
    $path = Join-Path ([IO.Path]::GetFullPath($OutputRoot)) ("{0}-{1}-{2}" -f $Name,(Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssfffZ'),([guid]::NewGuid().ToString('N').Substring(0,8)))
    # WhatIf concerne le tenant ; le rapport local doit rester disponible pour la revue du plan.
    $null = New-Item -ItemType Directory -Path $path -Force -WhatIf:$false -Confirm:$false
    return $path
}

function Export-M365Report {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Folder, [Parameter(Mandatory)][string]$Name,
          [AllowEmptyCollection()][object[]]$Data = @())
    if ($Name -notmatch '^[A-Za-z0-9-]+$') { throw 'Nom de rapport invalide.' }
    $rows = @($Data | Where-Object { $null -ne $_ })
    ConvertTo-Json -InputObject $rows -Depth 30 | Set-Content -LiteralPath (Join-Path $Folder "$Name.json") -Encoding utf8 -WhatIf:$false -Confirm:$false
    if ($rows.Count -gt 0) {
        $flat = foreach ($row in $rows) {
            $obj = [ordered]@{}
            foreach ($p in $row.PSObject.Properties) {
                $v = $p.Value
                if ($null -ne $v -and $v -isnot [string] -and $v -isnot [ValueType]) { $v = ConvertTo-Json -InputObject $v -Depth 20 -Compress }
                $obj[$p.Name] = $v
            }
            [pscustomobject]$obj
        }
        $flat | Export-Csv -LiteralPath (Join-Path $Folder "$Name.csv") -NoTypeInformation -Encoding utf8 -WhatIf:$false -Confirm:$false
    } else { 'ReportEmpty' | Set-Content -LiteralPath (Join-Path $Folder "$Name.csv") -Encoding utf8 -WhatIf:$false -Confirm:$false }
    [pscustomobject]@{Report=$Name;Rows=$rows.Count;CollectedUtc=[datetime]::UtcNow.ToString('o');Computer=$env:COMPUTERNAME} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $Folder "$Name.metadata.json") -Encoding utf8 -WhatIf:$false -Confirm:$false
    Write-Host "Rapport : $Folder ($($rows.Count) lignes pour $Name)"
}

function Invoke-M365Graph {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Uri,
          [ValidateSet('GET','POST','PATCH','PUT','DELETE')][string]$Method='GET', [object]$Body,
          [ValidateRange(0,10)][int]$MaxRetries=5)
    # Chemins relatifs seulement : empeche l'envoi accidentel d'un jeton a un autre hote.
    if ($Uri -notmatch '^/v1\.0/' -or $Uri -match '[\r\n]') { throw 'Seuls les chemins relatifs Graph /v1.0/ sont autorises.' }
    $args = @{Method=$Method;Uri=$Uri;OutputType='PSObject';ErrorAction='Stop'}
    if ($PSBoundParameters.ContainsKey('Body')) { $args.Body = ConvertTo-Json -InputObject $Body -Depth 30 -Compress; $args.ContentType='application/json' }
    for ($attempt=0; ; $attempt++) {
        try { return Invoke-MgGraphRequest @args }
        catch {
            $status = 0
            if ($_.Exception.PSObject.Properties['Response'] -and $_.Exception.Response) {
                try { $status = [int]$_.Exception.Response.StatusCode } catch { $status = 0 }
            }
            # Aucune repetition automatique des ecritures : une reponse perdue peut masquer une operation reussie.
            if ($Method -ne 'GET' -or $status -notin @(429,503,504) -or $attempt -ge $MaxRetries) { throw }
            $seconds = [Math]::Min(45,[Math]::Pow(2,$attempt+1)) + (Get-Random -Minimum 0 -Maximum 3)
            try {
                $retry = $_.Exception.Response.Headers.RetryAfter
                if ($retry.Delta) { $seconds = [Math]::Max($seconds,$retry.Delta.TotalSeconds) }
                elseif ($retry.Date) { $seconds = [Math]::Max($seconds,($retry.Date.UtcDateTime-[datetime]::UtcNow).TotalSeconds) }
            } catch { }
            if ($seconds -gt 60) { throw 'Retry-After > 60 s : relancer plus tard, ne pas marteler Graph.' }
            Start-Sleep -Seconds ([int][Math]::Ceiling($seconds))
        }
    }
}

function Get-M365GraphCollection {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Uri)
    $seen = [Collections.Generic.HashSet[string]]::new()
    while ($Uri) {
        if (-not $seen.Add($Uri)) { throw 'Boucle de pagination Graph detectee.' }
        $page = Invoke-M365Graph -Uri $Uri
        if (-not $page.PSObject.Properties['value']) { throw 'La reponse Graph attendue n est pas une collection.' }
        foreach ($item in @($page.value)) { if ($null -ne $item) { $item } }
        $Uri = $null
        if ($page.PSObject.Properties['@odata.nextLink'] -and $page.'@odata.nextLink') {
            $next = [uri]$page.'@odata.nextLink'
            if ($next.Scheme -ne 'https' -or $next.Host -ne 'graph.microsoft.com' -or $next.Port -ne 443 -or $next.UserInfo) { throw 'Pagination hors Graph public refusee.' }
            $Uri = $next.PathAndQuery
        }
    }
}

function ConvertTo-M365Segment {
    param([Parameter(Mandatory)][string]$Value)
    return [uri]::EscapeDataString($Value)
}

function Import-M365Csv {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string[]]$RequiredColumns,
          [string]$UniqueColumn)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "CSV introuvable : $Path" }
    $rows = @(Import-Csv -LiteralPath $Path -Encoding utf8)
    if ($rows.Count -eq 0) { throw 'CSV vide. Separateur attendu : virgule, encodage UTF-8.' }
    $headers = @($rows[0].PSObject.Properties.Name)
    foreach ($column in $RequiredColumns) {
        if ($column -notin $headers) { throw "Colonne requise manquante : $column" }
        foreach ($row in $rows) { if ([string]::IsNullOrWhiteSpace([string]$row.$column)) { throw "Valeur vide dans $column. CSV rejete avant toute ecriture." } }
    }
    if ($UniqueColumn) {
        $duplicates = @($rows | Group-Object -Property $UniqueColumn | Where-Object Count -gt 1)
        if ($duplicates.Count -gt 0) { throw "Doublons dans $UniqueColumn. CSV rejete." }
    }
    return $rows
}

function Invoke-M365CsvChange {
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$Caller, [Parameter(Mandatory)][object[]]$Rows,
          [Parameter(Mandatory)][string]$Folder, [Parameter(Mandatory)][string]$Action,
          [Parameter(Mandatory)][scriptblock]$Validate, [Parameter(Mandatory)][scriptblock]$Execute,
          [switch]$Apply)
    # Prevalidation de TOUT le lot, avant la premiere ecriture.
    $plan = @()
    try {
        $plan = @(foreach ($row in $Rows) { & $Validate $row })
        if ($plan.Count -ne $Rows.Count) { throw 'Le validateur doit retourner exactement un objet plan par ligne.' }
        foreach ($item in $plan) { if (-not $item.PSObject.Properties['Target'] -or -not $item.Target) { throw 'Plan sans Target.' } }
    } catch {
        Export-M365Report -Folder $Folder -Name 'prevalidation-failure' -Data @([pscustomobject]@{Status='Rejected';Reason=$_.Exception.Message})
        throw
    }
    Export-M365Report -Folder $Folder -Name 'plan' -Data $plan
    $results = [Collections.Generic.List[object]]::new()
    foreach ($item in $plan) {
        $status = 'Planned'; $message = ''
        if ($Apply) {
            if ($Caller.ShouldProcess([string]$item.Target,$Action)) {
                try { $null = & $Execute $item; $status='Applied' }
                catch { $status='Failed'; $message=$_.Exception.Message }
            } else { $status='Skipped' }
        }
        $results.Add([pscustomobject]@{Target=$item.Target;Action=$Action;Status=$status;Message=$message;Utc=[datetime]::UtcNow.ToString('o')})
        # Journal persiste apres chaque cible, y compris en cas d'interruption ulterieure.
        Export-M365Report -Folder $Folder -Name 'results' -Data $results.ToArray()
    }
    if (@($results | Where-Object Status -eq 'Failed').Count -gt 0) { throw "Lot partiellement echoue. Lire $Folder/results.csv et reconcilier l'etat reel avant relance." }
}

Export-ModuleMember -Function Assert-M365Runtime,Assert-M365Context,Assert-PnPUrl,New-M365ReportFolder,Export-M365Report,Invoke-M365Graph,Get-M365GraphCollection,ConvertTo-M365Segment,Import-M365Csv,Invoke-M365CsvChange
